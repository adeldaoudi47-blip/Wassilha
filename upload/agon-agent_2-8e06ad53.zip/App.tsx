import React, { useState, useEffect, createContext, useContext, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  FlatList,
  ScrollView,
  Dimensions,
  Platform,
  Alert,
  KeyboardAvoidingView,
  ActivityIndicator,
  Switch,
  Modal,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useFonts } from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');

// === THEME ===
const COLORS = {
  primary: '#0E6B5E',
  primaryDark: '#0A4A41',
  primaryLight: '#E6F4F1',
  accent: '#FF7A00',
  accentLight: '#FFF1E0',
  accentDark: '#E66A00',
  background: '#F8FAF9',
  surface: '#FFFFFF',
  text: '#0F172A',
  textMuted: '#64748B',
  textLight: '#94A3B8',
  border: '#E2E8F0',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#0EA5E9',
  darkBg: '#0F172A',
};

// === TRANSLATIONS ===
const translations = {
  ar: {
    appName: 'وَصِّلها',
    appSub: 'WASSILHA',
    tagline: 'نقل بضائعك بثقة في القرارة',
    location: 'القرارة - غرداية',
    algeriaTime: 'UTC+1 • الجزائر',
    welcome: 'مرحبا بك في وصّلها',
    welcomeSub: 'منصة النقل المحلية بالدراجة ثلاثية العجلات لنقل كل أنواع البضائع بسرعة وأمان',
    startNow: 'ابدأ الآن',
    phoneLogin: 'تسجيل الدخول برقم الهاتف',
    phoneHint: 'رقم الهاتف',
    phonePlaceholder: '6XX XX XX XX',
    sendOTP: 'إرسال رمز التحقق',
    otpTitle: 'أدخل رمز التحقق',
    otpSub: 'أرسلنا رمز إلى',
    verify: 'تأكيد',
    resend: 'إعادة الإرسال',
    cargoTypes: 'نوع الحمولة',
    pickup: 'نقطة الاستلام',
    dropoff: 'نقطة التوصيل',
    currentLocation: 'موقعي الحالي',
    selectOnMap: 'حدد على الخريطة',
    weight: 'الوزن التقريبي',
    notes: 'ملاحظات للسائق',
    notesPlaceholder: 'مثال: الطابق الثاني، اتصل عند الوصول...',
    estimate: 'التكلفة التقديرية',
    requestTriporteur: 'اطلب Triporteur الآن',
    searchingDriver: 'جاري البحث عن سائق...',
    noDrivers: 'لا يوجد سائقون متاحون حاليا',
    orderDetails: 'تفاصيل الطلب',
    track: 'تتبع',
    history: 'طلباتي',
    profile: 'حسابي',
    home: 'الرئيسية',
    admin: 'الإدارة',
    driver: 'السائق',
    customer: 'الزبون',
    online: 'متصل',
    offline: 'غير متصل',
    incomingRequests: 'الطلبات الواردة',
    accept: 'قبول',
    reject: 'رفض',
    myTrips: 'رحلاتي',
    earnings: 'أرباحي',
    dashboard: 'لوحة التحكم',
    pricing: 'التسعير',
    drivers: 'السائقون',
    orders: 'الطلبات',
    totalOrders: 'إجمالي الطلبات',
    activeDrivers: 'السائقون النشطون',
    revenue: 'الإيرادات',
    avgDelivery: 'متوسط التوصيل',
    basePrice: 'السعر الأساسي',
    perKm: 'سعر الكيلومتر',
    cargoMultiplier: 'معامل الحمولة',
    save: 'حفظ',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    delivered: 'تم التوصيل',
    inTransit: 'في الطريق',
    pending: 'قيد الانتظار',
    accepted: 'تم القبول',
    pickedUp: 'تم الاستلام',
    dzd: 'دج',
    kg: 'كغ',
    km: 'كم',
    next: 'التالي',
    back: 'رجوع',
    language: 'اللغة',
    french: 'Français',
    arabic: 'العربية',
    logout: 'تسجيل الخروج',
    offlineMode: 'وضع عدم الاتصال',
    offlineDesc: 'سيتم حفظ طلباتك وإرسالها عند عودة الإنترنت',
    securedBy: 'محمي بواسطة تشفير OTP و Supabase',
    support24: 'دعم محلي 7/7 في القرارة',
    cargo: {
      parcel: 'طرود وكوليات',
      goods: 'بضائع وسلع',
      shop: 'طلبيات المحلات',
      furniture: 'أثاث',
      appliance: 'أجهزة كهرومنزلية',
      construction: 'مواد بناء',
      personal: 'أغراض شخصية',
      other: 'أخرى',
    },
    cargoDesc: {
      parcel: 'صناديق، كولييات',
      goods: 'سلع تجارية',
      shop: 'توصيل محلات',
      furniture: 'أثاث منزلي',
      appliance: 'ثلاجة، غسالة...',
      construction: 'إسمنت، حديد...',
      personal: 'أمتعة خاصة',
      other: 'حمولة متنوعة',
    },
    status: {
      searching: 'البحث عن سائق',
      accepted: 'السائق في الطريق للاستلام',
      picked: 'تم الاستلام - في الطريق للتوصيل',
      delivered: 'تم التوصيل بنجاح',
    },
    driverFound: 'تم العثور على سائق!',
    driverInfo: 'معلومات السائق',
    call: 'اتصال',
    chat: 'محادثة',
    rate: 'تقييم',
    priceConfig: 'إعدادات التسعير (قابلة للتعديل من الإدارة)',
    orderCreated: 'تم إنشاء الطلب بنجاح!',
    willNotify: 'سيتم إشعارك عند قبول سائق لطلبك',
  },
  fr: {
    appName: 'WASSILHA',
    appSub: 'وَصِّلها',
    tagline: 'Transport de marchandises à El Guerrara',
    location: 'El Guerrara - Ghardaïa',
    algeriaTime: 'UTC+1 • Algérie',
    welcome: 'Bienvenue sur WASSILHA',
    welcomeSub: 'Plateforme locale de transport triporteur pour toutes vos marchandises, rapide et sécurisée',
    startNow: 'Commencer',
    phoneLogin: 'Connexion par téléphone',
    phoneHint: 'Numéro de téléphone',
    phonePlaceholder: '6XX XX XX XX',
    sendOTP: 'Envoyer code OTP',
    otpTitle: 'Entrez le code',
    otpSub: 'Code envoyé au',
    verify: 'Vérifier',
    resend: 'Renvoyer',
    cargoTypes: 'Type de cargaison',
    pickup: 'Point de ramassage',
    dropoff: 'Point de livraison',
    currentLocation: 'Ma position',
    selectOnMap: 'Choisir sur carte',
    weight: 'Poids approximatif',
    notes: 'Notes pour le chauffeur',
    notesPlaceholder: 'Ex: 2ème étage, appeler à l\'arrivée...',
    estimate: 'Estimation',
    requestTriporteur: 'Commander un Triporteur',
    searchingDriver: 'Recherche de chauffeur...',
    noDrivers: 'Aucun chauffeur disponible',
    orderDetails: 'Détails commande',
    track: 'Suivi',
    history: 'Mes commandes',
    profile: 'Profil',
    home: 'Accueil',
    admin: 'Admin',
    driver: 'Chauffeur',
    customer: 'Client',
    online: 'En ligne',
    offline: 'Hors ligne',
    incomingRequests: 'Demandes entrantes',
    accept: 'Accepter',
    reject: 'Refuser',
    myTrips: 'Mes courses',
    earnings: 'Revenus',
    dashboard: 'Tableau de bord',
    pricing: 'Tarification',
    drivers: 'Chauffeurs',
    orders: 'Commandes',
    totalOrders: 'Total commandes',
    activeDrivers: 'Chauffeurs actifs',
    revenue: 'Revenu',
    avgDelivery: 'Livraison moy.',
    basePrice: 'Prix de base',
    perKm: 'Prix par km',
    cargoMultiplier: 'Coeff. cargaison',
    save: 'Enregistrer',
    cancel: 'Annuler',
    confirm: 'Confirmer',
    delivered: 'Livré',
    inTransit: 'En transit',
    pending: 'En attente',
    accepted: 'Accepté',
    pickedUp: 'Ramassé',
    dzd: 'DA',
    kg: 'kg',
    km: 'km',
    next: 'Suivant',
    back: 'Retour',
    language: 'Langue',
    french: 'Français',
    arabic: 'العربية',
    logout: 'Déconnexion',
    offlineMode: 'Mode hors ligne',
    offlineDesc: 'Vos commandes seront sauvegardées et envoyées à la reconnexion',
    securedBy: 'Sécurisé par chiffrement OTP & Supabase',
    support24: 'Support local 7/7 à Guerrara',
    cargo: {
      parcel: 'Colis',
      goods: 'Marchandises',
      shop: 'Commandes magasins',
      furniture: 'Meubles',
      appliance: 'Électroménager',
      construction: 'Matériaux',
      personal: 'Effets personnels',
      other: 'Autre',
    },
    cargoDesc: {
      parcel: 'Boîtes, colis',
      goods: 'Produits commerciaux',
      shop: 'Livraison boutiques',
      furniture: 'Mobilier',
      appliance: 'Frigo, machine...',
      construction: 'Ciment, fer...',
      personal: 'Bagages perso',
      other: 'Divers',
    },
    status: {
      searching: 'Recherche chauffeur',
      accepted: 'Chauffeur en route',
      picked: 'Ramassé - en livraison',
      delivered: 'Livré avec succès',
    },
    driverFound: 'Chauffeur trouvé !',
    driverInfo: 'Infos chauffeur',
    call: 'Appeler',
    chat: 'Message',
    rate: 'Noter',
    priceConfig: 'Configuration tarifs (modifiable par admin)',
    orderCreated: 'Commande créée !',
    willNotify: 'Vous serez notifié dès acceptation',
  },
};

// === TYPES ===
type CargoKey = 'parcel' | 'goods' | 'shop' | 'furniture' | 'appliance' | 'construction' | 'personal' | 'other';
type OrderStatus = 'searching' | 'accepted' | 'picked' | 'delivered' | 'cancelled';
type Role = 'customer' | 'driver' | 'admin';

interface PricingConfig {
  basePrice: number;
  perKm: number;
  multipliers: Record<CargoKey, number>;
}

interface Order {
  id: string;
  cargoType: CargoKey;
  pickup: string;
  dropoff: string;
  weight: number;
  distance: number;
  price: number;
  status: OrderStatus;
  createdAt: string;
  driverName?: string;
  driverPhone?: string;
  driverRating?: number;
  notes?: string;
}

// === CONTEXTS ===
const LanguageContext = createContext<{ lang: 'ar' | 'fr'; toggle: () => void; t: typeof translations.ar }>({
  lang: 'ar',
  toggle: () => {},
  t: translations.ar,
});

// === MOCK DATA ===
const CARGO_TYPES: { key: CargoKey; icon: string; color: string }[] = [
  { key: 'parcel', icon: 'cube', color: '#0EA5E9' },
  { key: 'goods', icon: 'layers', color: '#8B5CF6' },
  { key: 'shop', icon: 'storefront', color: '#F59E0B' },
  { key: 'furniture', icon: 'bed', color: '#EF4444' },
  { key: 'appliance', icon: 'tv', color: '#10B981' },
  { key: 'construction', icon: 'construct', color: '#6B7280' },
  { key: 'personal', icon: 'bag-handle', color: '#EC4899' },
  { key: 'other', icon: 'ellipsis-horizontal-circle', color: '#64748B' },
];

const GUERRARA_LOCATIONS = [
  'حي 05 جويلية - القرارة',
  'وسط المدينة - القرارة',
  'حي المستقبل - القرارة',
  'طريق غرداية - القرارة',
  'سوق القرارة المركزي',
  'حي النصر - القرارة',
  'المنطقة الصناعية - القرارة',
  'حي الواحة - القرارة',
];

const MOCK_DRIVERS = [
  { name: 'أحمد بن سالم', phone: '0555123456', rating: 4.9, trips: 342, triporteur: 'Triporteur 125cc - أزرق' },
  { name: 'محمد لعروسي', phone: '0661234789', rating: 4.7, trips: 210, triporteur: 'Triporteur 150cc - أبيض' },
  { name: 'ياسين قاسمي', phone: '0770987654', rating: 4.8, trips: 189, triporteur: 'Triporteur 125cc - أحمر' },
];

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// === COMPONENTS ===

function MapPlaceholder({ lang, pickup, dropoff, showDriver }: any) {
  const isAr = lang === 'ar';
  return (
    <View style={styles.mapContainer}>
      {/* Map Grid Background */}
      <View style={styles.mapGrid}>
        {/* Roads */}
        <View style={[styles.roadH, { top: '30%' }]} />
        <View style={[styles.roadH, { top: '60%', opacity: 0.6 }]} />
        <View style={[styles.roadV, { left: '30%' }]} />
        <View style={[styles.roadV, { left: '70%', opacity: 0.6 }]} />
        {/* District blocks */}
        <View style={[styles.mapBlock, { top: '10%', left: '10%', backgroundColor: '#E6F4F1' }]} />
        <View style={[styles.mapBlock, { top: '10%', right: '10%', backgroundColor: '#FFF1E0' }]} />
        <View style={[styles.mapBlock, { bottom: '15%', left: '10%', backgroundColor: '#F1F5F9' }]} />
        <View style={[styles.mapBlock, { bottom: '15%', right: '10%', backgroundColor: '#E6F4F1' }]} />

        {/* Pickup Pin */}
        <View style={[styles.mapPin, { top: '35%', left: '28%', backgroundColor: COLORS.primary }]}>
          <Ionicons name="location" size={16} color="#fff" />
        </View>
        {/* Dropoff Pin */}
        <View style={[styles.mapPin, { top: '58%', left: '68%', backgroundColor: COLORS.accent }]}>
          <Ionicons name="flag" size={14} color="#fff" />
        </View>
        {/* Driver moving */}
        {showDriver && (
          <View style={[styles.mapPin, { top: '45%', left: '45%', backgroundColor: COLORS.darkBg, width: 36, height: 36, borderRadius: 18, borderWidth: 3, borderColor: '#fff' }]}>
            <Ionicons name="bicycle" size={18} color="#fff" />
          </View>
        )}
        {/* Dashed path */}
        <View style={styles.dashedPath} />
        {/* Distance badge */}
        <View style={[styles.distanceBadge, { alignSelf: isAr ? 'flex-end' : 'flex-start' }]}>
          <Ionicons name="navigate" size={12} color={COLORS.primary} />
          <Text style={styles.distanceText}>3.8 كم • 12 دقيقة</Text>
        </View>
      </View>

      {/* Map overlay top */}
      <View style={styles.mapTopOverlay}>
        <View style={styles.mapSearchBar}>
          <Ionicons name="search" size={16} color={COLORS.textMuted} />
          <Text style={styles.mapSearchText}>{isAr ? 'القرارة، غرداية' : 'El Guerrara, Ghardaïa'}</Text>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>LIVE</Text>
        </View>
        <TouchableOpacity style={styles.mapLocateBtn}>
          <Ionicons name="locate" size={20} color={COLORS.primary} />
        </TouchableOpacity>
      </View>

      {/* Map attribution */}
      <View style={styles.mapAttribution}>
        <Text style={styles.mapAttrText}>Mapbox • Supabase Realtime • القرارة UTC+1</Text>
      </View>
    </View>
  );
}

// === SCREENS ===

function OnboardingScreen({ navigation }: any) {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: COLORS.primary }]}>
      <StatusBar style="light" />
      {/* Decorative circles */}
      <View style={[styles.decoCircle, { width: 400, height: 400, top: -100, right: -100, opacity: 0.08 }]} />
      <View style={[styles.decoCircle, { width: 300, height: 300, bottom: 100, left: -80, opacity: 0.05 }]} />

      <View style={styles.onboardingHeader}>
        <View style={styles.logoRow}>
          <View style={styles.logoBox}>
            <Ionicons name="cube" size={28} color={COLORS.primary} />
          </View>
          <View>
            <Text style={[styles.logoText, { textAlign: isAr ? 'right' : 'left' }]}>{t.appName}</Text>
            <Text style={styles.logoSub}>{t.appSub} • TRI PORTEUR</Text>
          </View>
          <View style={styles.badgeLive}>
            <View style={styles.liveDotSmall} />
            <Text style={styles.badgeLiveText}>القرارة</Text>
          </View>
        </View>
        {/* Language toggle top */}
        <View style={styles.langToggleTop}>
          <TouchableOpacity style={[styles.langBtn, lang === 'ar' && styles.langBtnActive]} onPress={() => {}}>
            <Text style={[styles.langBtnText, lang === 'ar' && styles.langBtnTextActive]}>AR</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.langBtn, lang === 'fr' && styles.langBtnActive]} onPress={() => {}}>
            <Text style={[styles.langBtnText, lang === 'fr' && styles.langBtnTextActive]}>FR</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.onboardingCard}>
        <View style={styles.illustrationWrap}>
          <View style={styles.illustrationBg}>
            <Ionicons name="bicycle" size={80} color={COLORS.primary} />
            <View style={styles.boxOnBike}>
              <Ionicons name="cube" size={22} color="#fff" />
            </View>
          </View>
          {/* floating badges */}
          <View style={[styles.floatBadge, { top: 10, right: -10 }]}>
            <Ionicons name="shield-checkmark" size={14} color={COLORS.success} />
            <Text style={styles.floatBadgeText}>آمن</Text>
          </View>
          <View style={[styles.floatBadge, { bottom: 10, left: -10 }]}>
            <Ionicons name="time" size={14} color={COLORS.accent} />
            <Text style={styles.floatBadgeText}>سريع</Text>
          </View>
        </View>

        <Text style={[styles.onboardingTitle, { textAlign: 'center' }]}>{t.welcome}</Text>
        <Text style={[styles.onboardingSub, { textAlign: 'center' }]}>{t.welcomeSub}</Text>

        <View style={styles.featuresRow}>
          <View style={styles.featureItem}>
            <View style={[styles.featureIcon, { backgroundColor: '#E6F4F1' }]}>
              <Ionicons name="cube-outline" size={20} color={COLORS.primary} />
            </View>
            <Text style={styles.featureLabel}>{isAr ? 'كل الحمولات' : 'Tout cargaison'}</Text>
          </View>
          <View style={styles.featureItem}>
            <View style={[styles.featureIcon, { backgroundColor: '#FFF1E0' }]}>
              <Ionicons name="cash-outline" size={20} color={COLORS.accent} />
            </View>
            <Text style={styles.featureLabel}>{isAr ? 'دفع عند التسليم' : 'Paiement livraison'}</Text>
          </View>
          <View style={styles.featureItem}>
            <View style={[styles.featureIcon, { backgroundColor: '#EFF6FF' }]}>
              <Ionicons name="map-outline" size={20} color={COLORS.info} />
            </View>
            <Text style={styles.featureLabel}>{isAr ? 'تتبع مباشر' : 'Suivi live'}</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.replace('Auth')}>
          <Text style={styles.primaryBtnText}>{t.startNow}</Text>
          <Ionicons name={isAr ? 'arrow-back' : 'arrow-forward'} size={20} color="#fff" />
        </TouchableOpacity>

        <View style={styles.secureRow}>
          <Ionicons name="lock-closed" size={12} color={COLORS.textMuted} />
          <Text style={styles.secureText}>{t.securedBy}</Text>
          <Text style={styles.secureDot}>•</Text>
          <Ionicons name="headset" size={12} color={COLORS.textMuted} />
          <Text style={styles.secureText}>{t.support24}</Text>
        </View>

        <Text style={styles.regionNote}>
          {isAr ? 'مخصص حاليا للتجربة داخل القرارة – غرداية فقط' : 'Phase pilote uniquement à El Guerrara - Ghardaïa'}
        </Text>
      </View>

      <View style={styles.bottomTech}>
        <Text style={styles.techText}>Flutter • Supabase • Mapbox • DZD • OTP</Text>
      </View>
    </SafeAreaView>
  );
}

function AuthScreen({ navigation }: any) {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);
  const otpRefs = [useRef<TextInput>(null), useRef<TextInput>(null), useRef<TextInput>(null), useRef<TextInput>(null)];
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState<Role>('customer');

  const handleSendOTP = () => {
    if (phone.length < 9) {
      Alert.alert(isAr ? 'تنبيه' : 'Attention', isAr ? 'أدخل رقم هاتف صحيح' : 'Entrez un numéro valide');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep('otp');
    }, 1200);
  };

  const handleVerify = () => {
    const code = otp.join('');
    if (code.length !== 4) {
      Alert.alert(isAr ? 'خطأ' : 'Erreur', isAr ? 'أدخل الرمز المكون من 4 أرقام' : 'Entrez le code à 4 chiffres');
      return;
    }
    setLoading(true);
    setTimeout(async () => {
      await AsyncStorage.setItem('wassilha_role', role);
      await AsyncStorage.setItem('wassilha_phone', phone);
      setLoading(false);
      navigation.replace('Main', { role });
    }, 1000);
  };

  const handleOtpChange = (val: string, idx: number) => {
    const newOtp = [...otp];
    newOtp[idx] = val;
    setOtp(newOtp);
    if (val && idx < 3) otpRefs[idx + 1].current?.focus();
    if (!val && idx > 0) otpRefs[idx - 1].current?.focus();
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.authContainer} keyboardShouldPersistTaps="handled">
          <TouchableOpacity onPress={() => navigation.goBack()} style={[styles.backBtn, { alignSelf: isAr ? 'flex-end' : 'flex-start' }]}>
            <Ionicons name={isAr ? 'arrow-forward' : 'arrow-back'} size={22} color={COLORS.text} />
          </TouchableOpacity>

          <View style={styles.authLogo}>
            <View style={[styles.logoBox, { width: 64, height: 64, borderRadius: 18 }]}>
              <Ionicons name="cube" size={32} color={COLORS.primary} />
            </View>
            <Text style={styles.authTitle}>{t.appName}</Text>
            <Text style={styles.authSub}>{t.tagline}</Text>
          </View>

          {/* Role selector */}
          <View style={styles.roleSelector}>
            {(['customer', 'driver', 'admin'] as Role[]).map((r) => (
              <TouchableOpacity key={r} onPress={() => setRole(r)} style={[styles.roleChip, role === r && styles.roleChipActive]}>
                <Ionicons
                  name={r === 'customer' ? 'person' : r === 'driver' ? 'bicycle' : 'shield-checkmark'}
                  size={16}
                  color={role === r ? '#fff' : COLORS.textMuted}
                />
                <Text style={[styles.roleChipText, role === r && styles.roleChipTextActive]}>
                  {r === 'customer' ? t.customer : r === 'driver' ? t.driver : t.admin}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.roleHint}>{isAr ? 'اختر دورك للتجربة (يمكن التبديل لاحقا)' : 'Choisissez votre rôle pour la démo'}</Text>

          {step === 'phone' ? (
            <View style={styles.authCard}>
              <Text style={[styles.authCardTitle, { textAlign: isAr ? 'right' : 'left' }]}>{t.phoneLogin}</Text>
              <Text style={[styles.authCardSub, { textAlign: isAr ? 'right' : 'left' }]}>
                {isAr ? 'سيصلك رمز تحقق عبر الرسائل القصيرة' : 'Vous recevrez un code par SMS'}
              </Text>

              <View style={[styles.phoneInputRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <View style={styles.countryCode}>
                  <Text style={styles.countryFlag}>🇩🇿</Text>
                  <Text style={styles.countryCodeText}>+213</Text>
                  <Ionicons name="chevron-down" size={14} color={COLORS.textMuted} />
                </View>
                <TextInput
                  style={[styles.phoneInput, { textAlign: isAr ? 'right' : 'left' }]}
                  placeholder={t.phonePlaceholder}
                  placeholderTextColor={COLORS.textLight}
                  keyboardType="phone-pad"
                  value={phone}
                  onChangeText={setPhone}
                  maxLength={10}
                />
              </View>

              <TouchableOpacity style={[styles.primaryBtn, { marginTop: 20 }]} onPress={handleSendOTP} disabled={loading}>
                {loading ? <ActivityIndicator color="#fff" /> : (
                  <>
                    <Text style={styles.primaryBtnText}>{t.sendOTP}</Text>
                    <Ionicons name={isAr ? 'arrow-back' : 'arrow-forward'} size={18} color="#fff" />
                  </>
                )}
              </TouchableOpacity>

              <View style={styles.otpInfo}>
                <Ionicons name="information-circle-outline" size={14} color={COLORS.textMuted} />
                <Text style={styles.otpInfoText}>{isAr ? 'الرمز التجريبي: 1234' : 'Code démo: 1234'}</Text>
              </View>
            </View>
          ) : (
            <View style={styles.authCard}>
              <Text style={[styles.authCardTitle, { textAlign: isAr ? 'right' : 'left' }]}>{t.otpTitle}</Text>
              <Text style={[styles.authCardSub, { textAlign: isAr ? 'right' : 'left' }]}>
                {t.otpSub} +213 {phone}
              </Text>

              <View style={styles.otpRow}>
                {otp.map((digit, idx) => (
                  <TextInput
                    key={idx}
                    ref={otpRefs[idx]}
                    style={[styles.otpInput, digit && styles.otpInputFilled]}
                    value={digit}
                    onChangeText={(v) => handleOtpChange(v.slice(-1), idx)}
                    keyboardType="number-pad"
                    maxLength={1}
                    textAlign="center"
                  />
                ))}
              </View>

              <TouchableOpacity style={[styles.primaryBtn, { marginTop: 20 }]} onPress={handleVerify} disabled={loading}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>{t.verify}</Text>}
              </TouchableOpacity>

              <TouchableOpacity style={styles.resendBtn} onPress={() => setStep('phone')}>
                <Text style={styles.resendText}>{t.resend} • {isAr ? 'تغيير الرقم' : 'Changer numéro'}</Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.secureRow}>
            <Ionicons name="shield-checkmark" size={14} color={COLORS.success} />
            <Text style={styles.secureText}>{t.securedBy}</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// === CUSTOMER HOME ===
function CustomerHomeScreen({ navigation }: any) {
  const { lang, t, toggle } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [selectedCargo, setSelectedCargo] = useState<CargoKey>('parcel');
  const [weight, setWeight] = useState(50);
  const [pickup, setPickup] = useState(GUERRARA_LOCATIONS[0]);
  const [dropoff, setDropoff] = useState(GUERRARA_LOCATIONS[1]);
  const [notes, setNotes] = useState('');
  const [showPricing, setShowPricing] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [pricing, setPricing] = useState<PricingConfig>({
    basePrice: 300,
    perKm: 45,
    multipliers: { parcel: 1, goods: 1.2, shop: 1.1, furniture: 1.6, appliance: 1.5, construction: 1.8, personal: 1, other: 1.1 },
  });

  const distance = 3.8;
  const estimatedPrice = Math.round((pricing.basePrice + distance * pricing.perKm) * (pricing.multipliers[selectedCargo] || 1) + weight * 0.5);

  const handleRequest = async () => {
    const newOrder: Order = {
      id: 'WS-' + Date.now().toString().slice(-6),
      cargoType: selectedCargo,
      pickup,
      dropoff,
      weight,
      distance,
      price: estimatedPrice,
      status: 'searching',
      createdAt: new Date().toISOString(),
      notes,
    };
    // Save to storage for offline resilience
    try {
      const existing = await AsyncStorage.getItem('wassilha_orders');
      const orders = existing ? JSON.parse(existing) : [];
      orders.unshift(newOrder);
      await AsyncStorage.setItem('wassilha_orders', JSON.stringify(orders));
      // also queue if offline
      if (isOffline) {
        const queue = await AsyncStorage.getItem('wassilha_queue');
        const q = queue ? JSON.parse(queue) : [];
        q.push(newOrder);
        await AsyncStorage.setItem('wassilha_queue', JSON.stringify(q));
      }
    } catch {}
    navigation.navigate('Tracking', { order: newOrder });
  };

  const togglePickupDropoff = () => {
    const tmp = pickup;
    setPickup(dropoff);
    setDropoff(tmp);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      {/* Header */}
      <View style={[styles.customerHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
        <View style={[styles.headerLeft, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <View style={styles.logoBoxSmall}>
            <Ionicons name="cube" size={20} color={COLORS.primary} />
          </View>
          <View style={{ alignItems: isAr ? 'flex-end' : 'flex-start' }}>
            <Text style={styles.headerTitle}>WASSILHA</Text>
            <View style={[styles.locationRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="location" size={12} color={COLORS.accent} />
              <Text style={styles.headerLocation}>{t.location}</Text>
              <View style={styles.onlineDot} />
            </View>
          </View>
        </View>
        <View style={[styles.headerActions, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <TouchableOpacity onPress={toggle} style={styles.headerIconBtn}>
            <Text style={styles.headerLang}>{lang === 'ar' ? 'FR' : 'AR'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerIconBtn} onPress={() => setIsOffline(!isOffline)}>
            <Ionicons name={isOffline ? 'cloud-offline' : 'cloud-done'} size={18} color={isOffline ? COLORS.error : COLORS.success} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.avatarBtn}>
            <Text style={styles.avatarText}>م</Text>
          </TouchableOpacity>
        </View>
      </View>

      {isOffline && (
        <View style={[styles.offlineBanner, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <Ionicons name="cloud-offline" size={16} color="#fff" />
          <Text style={styles.offlineText}>{isAr ? 'وضع عدم الاتصال - سيتم حفظ الطلب محليا' : 'Mode hors ligne - commande sauvegardée localement'}</Text>
        </View>
      )}

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Map */}
        <MapPlaceholder lang={lang} pickup={pickup} dropoff={dropoff} />

        {/* Pickup / Dropoff Card */}
        <View style={styles.locationsCard}>
          <View style={styles.locationsTimeline}>
            <View style={styles.timelineDotWrap}>
              <View style={[styles.timelineDot, { backgroundColor: COLORS.primary }]} />
              <View style={styles.timelineLine} />
              <View style={[styles.timelineDot, { backgroundColor: COLORS.accent }]} />
            </View>
            <View style={{ flex: 1, gap: 12 }}>
              <TouchableOpacity style={[styles.locationInput, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                  <Text style={styles.locationLabel}>{t.pickup}</Text>
                  <Text style={styles.locationValue} numberOfLines={1}>{pickup}</Text>
                </View>
                <View style={[styles.locationIcon, { backgroundColor: COLORS.primaryLight }]}>
                  <Ionicons name="navigate" size={16} color={COLORS.primary} />
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={[styles.locationInput, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                  <Text style={styles.locationLabel}>{t.dropoff}</Text>
                  <Text style={styles.locationValue} numberOfLines={1}>{dropoff}</Text>
                </View>
                <View style={[styles.locationIcon, { backgroundColor: COLORS.accentLight }]}>
                  <Ionicons name="flag" size={16} color={COLORS.accent} />
                </View>
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.swapBtn} onPress={togglePickupDropoff}>
              <Ionicons name="swap-vertical" size={18} color={COLORS.primary} />
            </TouchableOpacity>
          </View>

          <View style={[styles.locationActions, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <TouchableOpacity style={[styles.locActionBtn, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="locate" size={14} color={COLORS.primary} />
              <Text style={styles.locActionText}>{t.currentLocation}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.locActionBtn, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="map" size={14} color={COLORS.primary} />
              <Text style={styles.locActionText}>{t.selectOnMap}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Cargo Types */}
        <View style={styles.section}>
          <View style={[styles.sectionHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <Text style={styles.sectionTitle}>{t.cargoTypes}</Text>
            <Text style={styles.sectionSub}>{isAr ? 'اختر ما تريد نقله' : 'Choisissez le type'}</Text>
          </View>

          <View style={styles.cargoGrid}>
            {CARGO_TYPES.map((cargo) => {
              const isSelected = selectedCargo === cargo.key;
              return (
                <TouchableOpacity
                  key={cargo.key}
                  onPress={() => setSelectedCargo(cargo.key)}
                  style={[styles.cargoCard, isSelected && styles.cargoCardSelected, { borderColor: isSelected ? COLORS.primary : COLORS.border }]}
                >
                  {isSelected && (
                    <View style={styles.cargoCheck}>
                      <Ionicons name="checkmark" size={10} color="#fff" />
                    </View>
                  )}
                  <View style={[styles.cargoIcon, { backgroundColor: isSelected ? COLORS.primary : cargo.color + '15' }]}>
                    <Ionicons name={cargo.icon as any} size={22} color={isSelected ? '#fff' : cargo.color} />
                  </View>
                  <Text style={[styles.cargoLabel, isSelected && { color: COLORS.primary }]} numberOfLines={1}>
                    {t.cargo[cargo.key]}
                  </Text>
                  <Text style={styles.cargoDesc} numberOfLines={1}>
                    {t.cargoDesc[cargo.key]}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Weight */}
        <View style={styles.section}>
          <View style={[styles.sectionHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <Text style={styles.sectionTitle}>{t.weight}</Text>
            <View style={[styles.weightBadge, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.weightBadgeText}>{weight} {t.kg}</Text>
              <Ionicons name="scale" size={12} color={COLORS.primary} />
            </View>
          </View>
          <View style={styles.weightRow}>
            <TouchableOpacity style={styles.weightBtn} onPress={() => setWeight(Math.max(5, weight - 10))}>
              <Ionicons name="remove" size={20} color={COLORS.primary} />
            </TouchableOpacity>
            <View style={styles.weightSliderWrap}>
              <View style={styles.weightTrack}>
                <View style={[styles.weightFill, { width: `${(weight / 500) * 100}%` }]} />
                <View style={[styles.weightThumb, { left: `${(weight / 500) * 100}%` }]} />
              </View>
              <View style={[styles.weightLabels, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <Text style={styles.weightLabel}>5 {t.kg}</Text>
                <Text style={styles.weightLabel}>500 {t.kg}</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.weightBtn} onPress={() => setWeight(Math.min(500, weight + 10))}>
              <Ionicons name="add" size={20} color={COLORS.primary} />
            </TouchableOpacity>
          </View>
          <View style={[styles.weightPresets, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            {[20, 50, 100, 200].map((w) => (
              <TouchableOpacity key={w} onPress={() => setWeight(w)} style={[styles.weightPreset, weight === w && styles.weightPresetActive]}>
                <Text style={[styles.weightPresetText, weight === w && styles.weightPresetTextActive]}>{w} {t.kg}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Notes */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { textAlign: isAr ? 'right' : 'left', marginBottom: 8 }]}>{t.notes}</Text>
          <View style={styles.notesInputWrap}>
            <TextInput
              style={[styles.notesInput, { textAlign: isAr ? 'right' : 'left' }]}
              placeholder={t.notesPlaceholder}
              placeholderTextColor={COLORS.textLight}
              value={notes}
              onChangeText={setNotes}
              multiline
            />
            <Ionicons name="chatbubble-ellipses-outline" size={18} color={COLORS.textLight} style={{ position: 'absolute', top: 12, right: isAr ? undefined : 12, left: isAr ? 12 : undefined }} />
          </View>
        </View>

        {/* Price Estimate */}
        <View style={styles.priceCard}>
          <View style={[styles.priceHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.priceIcon, { backgroundColor: COLORS.primary }]}>
              <Ionicons name="calculator" size={18} color="#fff" />
            </View>
            <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.priceTitle}>{t.estimate}</Text>
              <Text style={styles.priceSub}>
                {distance} {t.km} • {t.cargo[selectedCargo]} • {pricing.basePrice} {t.dzd} + {pricing.perKm}/{t.km}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setShowPricing(true)}>
              <Ionicons name="settings-outline" size={18} color={COLORS.textMuted} />
            </TouchableOpacity>
          </View>

          <View style={[styles.priceRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={{ alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.priceValue}>{estimatedPrice.toLocaleString('fr-DZ')} {t.dzd}</Text>
              <Text style={styles.priceVat}>{isAr ? 'شامل كل الرسوم • دفع عند التسليم' : 'TTC • Paiement à la livraison'}</Text>
            </View>
            <View style={[styles.priceBreakdown, { alignItems: isAr ? 'flex-end' : 'flex-start' }]}>
              <Text style={styles.priceBreakText}>
                {isAr ? `أساسي ${pricing.basePrice} + مسافة ${Math.round(distance * pricing.perKm)} + حمولة ×${pricing.multipliers[selectedCargo]}` : `Base ${pricing.basePrice} + distance ${Math.round(distance * pricing.perKm)} ×${pricing.multipliers[selectedCargo]}`}
              </Text>
            </View>
          </View>

          <View style={[styles.priceFeatures, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.priceFeature, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="shield-checkmark" size={12} color={COLORS.success} />
              <Text style={styles.priceFeatureText}>{isAr ? 'تأمين الحمولة' : 'Assurance incluse'}</Text>
            </View>
            <View style={[styles.priceFeature, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="time" size={12} color={COLORS.accent} />
              <Text style={styles.priceFeatureText}>12-18 {isAr ? 'دقيقة' : 'min'}</Text>
            </View>
          </View>
        </View>

        <TouchableOpacity style={styles.primaryBtnLarge} onPress={handleRequest}>
          <Ionicons name="bicycle" size={22} color="#fff" />
          <Text style={styles.primaryBtnLargeText}>{t.requestTriporteur}</Text>
          <View style={styles.pricePill}>
            <Text style={styles.pricePillText}>{estimatedPrice} {t.dzd}</Text>
          </View>
        </TouchableOpacity>

        <Text style={styles.offlineNote}>
          <Ionicons name="cloud-offline-outline" size={12} color={COLORS.textMuted} /> {t.offlineDesc}
        </Text>
      </ScrollView>

      {/* Pricing modal (admin configurable) */}
      <Modal visible={showPricing} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={[styles.modalHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.modalTitle}>{t.priceConfig}</Text>
              <TouchableOpacity onPress={() => setShowPricing(false)}>
                <Ionicons name="close" size={24} color={COLORS.text} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.modalSub, { textAlign: isAr ? 'right' : 'left' }]}>
              {isAr ? 'يمكن للإدارة تعديل التسعير في الوقت الحقيقي عبر لوحة التحكم' : 'Modifiable en temps réel par l\'administration'}
            </Text>
            <View style={styles.pricingEditRow}>
              <Text style={styles.pricingLabel}>{t.basePrice}</Text>
              <TextInput style={styles.pricingInput} value={String(pricing.basePrice)} keyboardType="numeric" onChangeText={(v) => setPricing({ ...pricing, basePrice: parseInt(v) || 0 })} />
              <Text style={styles.pricingUnit}>{t.dzd}</Text>
            </View>
            <View style={styles.pricingEditRow}>
              <Text style={styles.pricingLabel}>{t.perKm}</Text>
              <TextInput style={styles.pricingInput} value={String(pricing.perKm)} keyboardType="numeric" onChangeText={(v) => setPricing({ ...pricing, perKm: parseInt(v) || 0 })} />
              <Text style={styles.pricingUnit}>{t.dzd}</Text>
            </View>
            <TouchableOpacity style={styles.primaryBtn} onPress={() => setShowPricing(false)}>
              <Text style={styles.primaryBtnText}>{t.save}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function TrackingScreen({ route, navigation }: any) {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const order: Order = route?.params?.order || {
    id: 'WS-48291',
    cargoType: 'furniture',
    pickup: GUERRARA_LOCATIONS[0],
    dropoff: GUERRARA_LOCATIONS[1],
    weight: 80,
    distance: 3.8,
    price: 890,
    status: 'searching',
    createdAt: new Date().toISOString(),
  };
  const [status, setStatus] = useState<OrderStatus>(order.status);
  const [driver] = useState(MOCK_DRIVERS[0]);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStatus('accepted'), 3000),
      setTimeout(() => setStatus('picked'), 8000),
      setTimeout(() => setStatus('delivered'), 15000),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  const steps: { key: OrderStatus; label: string; icon: string }[] = [
    { key: 'searching', label: t.status.searching, icon: 'search' },
    { key: 'accepted', label: t.status.accepted, icon: 'bicycle' },
    { key: 'picked', label: t.status.picked, icon: 'cube' },
    { key: 'delivered', label: t.status.delivered, icon: 'checkmark-done' },
  ];
  const currentIndex = steps.findIndex((s) => s.key === status);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.trackHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backCircle}>
          <Ionicons name={isAr ? 'arrow-forward' : 'arrow-back'} size={20} color={COLORS.text} />
        </TouchableOpacity>
        <View style={{ alignItems: isAr ? 'flex-end' : 'flex-start', flex: 1 }}>
          <Text style={styles.trackTitle}>{isAr ? 'تتبع الطلب' : 'Suivi commande'}</Text>
          <Text style={styles.trackId}>{order.id} • {new Date(order.createdAt).toLocaleTimeString('fr-DZ', { hour: '2-digit', minute: '2-digit' })} UTC+1</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: status === 'delivered' ? COLORS.success : status === 'searching' ? COLORS.warning : COLORS.info }]}>
          <Text style={styles.statusBadgeText}>
            {status === 'searching' ? t.pending : status === 'accepted' ? t.accepted : status === 'picked' ? t.inTransit : t.delivered}
          </Text>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 30 }}>
        <MapPlaceholder lang={lang} showDriver={status !== 'searching'} />

        {/* Status Card */}
        <View style={styles.trackCard}>
          {status === 'searching' ? (
            <View style={[styles.searchingBox, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <ActivityIndicator color={COLORS.primary} />
              <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                <Text style={styles.searchingTitle}>{t.searchingDriver}</Text>
                <Text style={styles.searchingSub}>{isAr ? 'نبحث عن أقرب Triporteur متاح في القرارة...' : 'Recherche du triporteur le plus proche...'}</Text>
              </View>
            </View>
          ) : (
            <View style={[styles.driverFoundBox, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <View style={styles.driverAvatar}>
                <Text style={styles.driverAvatarText}>{driver.name.charAt(0)}</Text>
                <View style={styles.driverOnlineDot} />
              </View>
              <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                <Text style={styles.driverFoundTitle}>{t.driverFound}</Text>
                <Text style={styles.driverName}>{driver.name} • ⭐ {driver.rating}</Text>
                <Text style={styles.driverTri}>{driver.triporteur}</Text>
              </View>
              <View style={[styles.driverActions, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <TouchableOpacity style={[styles.driverActionBtn, { backgroundColor: COLORS.success }]}>
                  <Ionicons name="call" size={18} color="#fff" />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.driverActionBtn, { backgroundColor: COLORS.primary }]}>
                  <Ionicons name="chatbubble" size={18} color="#fff" />
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Timeline */}
          <View style={[styles.timeline, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            {steps.map((step, idx) => {
              const isDone = idx <= currentIndex;
              const isCurrent = idx === currentIndex;
              return (
                <View key={step.key} style={styles.timelineStep}>
                  <View style={[styles.timelineCircle, isDone && styles.timelineCircleDone, isCurrent && styles.timelineCircleCurrent]}>
                    <Ionicons name={step.icon as any} size={14} color={isDone ? '#fff' : COLORS.textLight} />
                  </View>
                  <Text style={[styles.timelineLabel, isDone && styles.timelineLabelDone]}>{step.label}</Text>
                  {idx < steps.length - 1 && <View style={[styles.timelineConnector, isDone && { backgroundColor: COLORS.primary }]} />}
                </View>
              );
            })}
          </View>

          {/* Order details */}
          <View style={styles.orderDetailBox}>
            <View style={[styles.orderDetailRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderDetailLabel}>{isAr ? 'الحمولة' : 'Cargaison'}</Text>
              <Text style={styles.orderDetailValue}>{t.cargo[order.cargoType]} • {order.weight} {t.kg}</Text>
            </View>
            <View style={[styles.orderDetailRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderDetailLabel}>{isAr ? 'المسافة' : 'Distance'}</Text>
              <Text style={styles.orderDetailValue}>{order.distance} {t.km}</Text>
            </View>
            <View style={[styles.orderDetailRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderDetailLabel}>{isAr ? 'السعر' : 'Prix'}</Text>
              <Text style={[styles.orderDetailValue, { color: COLORS.primary, fontWeight: '800' }]}>{order.price} {t.dzd}</Text>
            </View>
            <View style={[styles.orderDetailRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderDetailLabel}>{t.pickup}</Text>
              <Text style={styles.orderDetailValue} numberOfLines={1}>{order.pickup}</Text>
            </View>
            <View style={[styles.orderDetailRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderDetailLabel}>{t.dropoff}</Text>
              <Text style={styles.orderDetailValue} numberOfLines={1}>{order.dropoff}</Text>
            </View>
          </View>

          {status === 'delivered' && (
            <View style={styles.deliveredCelebrate}>
              <Ionicons name="checkmark-circle" size={48} color={COLORS.success} />
              <Text style={styles.deliveredTitle}>{isAr ? 'تم التوصيل بنجاح! 🎉' : 'Livraison réussie ! 🎉'}</Text>
              <Text style={styles.deliveredSub}>{isAr ? 'شكرا لاستخدامك وصّلها' : 'Merci d\'avoir utilisé WASSILHA'}</Text>
              <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate('CustomerHome')}>
                <Text style={styles.primaryBtnText}>{isAr ? 'طلب جديد' : 'Nouvelle commande'}</Text>
              </TouchableOpacity>
            </View>
          )}

          {status !== 'delivered' && status !== 'searching' && (
            <View style={[styles.etaBox, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="time-outline" size={18} color={COLORS.primary} />
              <Text style={styles.etaText}>{isAr ? 'الوصول المتوقع: 12 دقيقة' : 'Arrivée estimée: 12 min'}</Text>
              <Text style={styles.etaLive}>LIVE</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function OrdersHistoryScreen() {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [orders, setOrders] = useState<Order[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadOrders = async () => {
    try {
      const stored = await AsyncStorage.getItem('wassilha_orders');
      if (stored) setOrders(JSON.parse(stored));
      else {
        // mock history
        const mock: Order[] = [
          { id: 'WS-38921', cargoType: 'parcel', pickup: GUERRARA_LOCATIONS[2], dropoff: GUERRARA_LOCATIONS[4], weight: 15, distance: 2.1, price: 420, status: 'delivered', createdAt: new Date(Date.now() - 86400000).toISOString(), driverName: 'أحمد بن سالم' },
          { id: 'WS-38902', cargoType: 'furniture', pickup: GUERRARA_LOCATIONS[0], dropoff: GUERRARA_LOCATIONS[5], weight: 120, distance: 4.5, price: 1120, status: 'delivered', createdAt: new Date(Date.now() - 172800000).toISOString(), driverName: 'ياسين قاسمي' },
          { id: 'WS-38871', cargoType: 'appliance', pickup: 'سوق القرارة', dropoff: GUERRARA_LOCATIONS[3], weight: 60, distance: 3.2, price: 780, status: 'cancelled', createdAt: new Date(Date.now() - 259200000).toISOString() },
        ];
        setOrders(mock);
      }
    } catch {}
  };

  useEffect(() => { loadOrders(); }, []);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => { loadOrders(); setRefreshing(false); }, 800);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.pageHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
        <Text style={styles.pageTitle}>{t.history}</Text>
        <View style={[styles.pageBadge, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <Text style={styles.pageBadgeText}>{orders.length} {isAr ? 'طلب' : 'commandes'}</Text>
        </View>
      </View>

      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        refreshing={refreshing}
        onRefresh={onRefresh}
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="receipt-outline" size={48} color={COLORS.textLight} />
            <Text style={styles.emptyTitle}>{isAr ? 'لا توجد طلبات بعد' : 'Aucune commande'}</Text>
            <Text style={styles.emptySub}>{isAr ? 'طلباتك ستظهر هنا' : 'Vos commandes apparaîtront ici'}</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.orderCard}>
            <View style={[styles.orderCardHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.orderId}>{item.id}</Text>
              <View style={[styles.orderStatus, { backgroundColor: item.status === 'delivered' ? '#DCFCE7' : item.status === 'cancelled' ? '#FEE2E2' : '#FEF3C7' }]}>
                <Text style={[styles.orderStatusText, { color: item.status === 'delivered' ? COLORS.success : item.status === 'cancelled' ? COLORS.error : COLORS.warning }]}>
                  {item.status === 'delivered' ? t.delivered : item.status === 'cancelled' ? (isAr ? 'ملغى' : 'Annulé') : t.pending}
                </Text>
              </View>
            </View>
            <View style={[styles.orderCardRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <View style={[styles.orderCargoIcon, { backgroundColor: CARGO_TYPES.find(c=>c.key===item.cargoType)?.color + '15' }]}>
                <Ionicons name={CARGO_TYPES.find(c=>c.key===item.cargoType)?.icon as any} size={16} color={CARGO_TYPES.find(c=>c.key===item.cargoType)?.color} />
              </View>
              <Text style={styles.orderCargoText}>{t.cargo[item.cargoType]} • {item.weight} {t.kg} • {item.distance} {t.km}</Text>
              <Text style={styles.orderPrice}>{item.price} {t.dzd}</Text>
            </View>
            <View style={[styles.orderRoute, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Ionicons name="location-outline" size={12} color={COLORS.textMuted} />
              <Text style={styles.orderRouteText} numberOfLines={1}>{item.pickup} → {item.dropoff}</Text>
            </View>
            <Text style={[styles.orderDate, { textAlign: isAr ? 'right' : 'left' }]}>
              {new Date(item.createdAt).toLocaleDateString(isAr ? 'ar-DZ' : 'fr-DZ')} • {new Date(item.createdAt).toLocaleTimeString('fr-DZ', { hour: '2-digit', minute: '2-digit' })} UTC+1
            </Text>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

function DriverHomeScreen() {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [isOnline, setIsOnline] = useState(true);
  const [incoming, setIncoming] = useState<Order[]>([
    { id: 'WS-49201', cargoType: 'construction', pickup: 'محل مواد البناء - القرارة', dropoff: GUERRARA_LOCATIONS[6], weight: 300, distance: 2.8, price: 1450, status: 'searching', createdAt: new Date().toISOString(), notes: 'إسمنت 10 أكياس' },
    { id: 'WS-49202', cargoType: 'shop', pickup: 'متجر الأقمشة وسط المدينة', dropoff: GUERRARA_LOCATIONS[2], weight: 25, distance: 1.9, price: 520, status: 'searching', createdAt: new Date().toISOString() },
    { id: 'WS-49203', cargoType: 'furniture', pickup: GUERRARA_LOCATIONS[0], dropoff: GUERRARA_LOCATIONS[3], weight: 90, distance: 3.5, price: 980, status: 'searching', createdAt: new Date().toISOString(), notes: 'طاولة + 4 كراسي' },
  ]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  const handleAccept = (order: Order) => {
    setActiveOrder({ ...order, status: 'accepted' });
    setIncoming(incoming.filter((o) => o.id !== order.id));
    Alert.alert(isAr ? 'تم القبول' : 'Accepté', isAr ? `تم قبول الطلب ${order.id}` : `Commande ${order.id} acceptée`);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.driverHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
        <View style={{ alignItems: isAr ? 'flex-end' : 'flex-start' }}>
          <Text style={styles.driverHeaderTitle}>{isAr ? 'مرحبا، أحمد 👋' : 'Salut, Ahmed 👋'}</Text>
          <Text style={styles.driverHeaderSub}>Triporteur 125cc • ⭐ 4.9 • 342 {isAr ? 'رحلة' : 'courses'}</Text>
        </View>
        <View style={[styles.onlineToggle, { flexDirection: isAr ? 'row-reverse' : 'row', backgroundColor: isOnline ? '#DCFCE7' : '#F1F5F9' }]}>
          <Text style={[styles.onlineText, { color: isOnline ? COLORS.success : COLORS.textMuted }]}>{isOnline ? t.online : t.offline}</Text>
          <Switch value={isOnline} onValueChange={setIsOnline} trackColor={{ true: COLORS.success, false: '#CBD5E1' }} thumbColor="#fff" />
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 100 }}>
        {/* Stats */}
        <View style={[styles.driverStats, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <View style={styles.driverStatCard}>
            <Text style={styles.driverStatValue}>8</Text>
            <Text style={styles.driverStatLabel}>{isAr ? 'طلبات اليوم' : 'Courses du jour'}</Text>
          </View>
          <View style={styles.driverStatCard}>
            <Text style={styles.driverStatValue}>6,840 {t.dzd}</Text>
            <Text style={styles.driverStatLabel}>{isAr ? 'أرباح اليوم' : 'Gains du jour'}</Text>
          </View>
          <View style={styles.driverStatCard}>
            <Text style={styles.driverStatValue}>4.9 ⭐</Text>
            <Text style={styles.driverStatLabel}>{isAr ? 'التقييم' : 'Note'}</Text>
          </View>
        </View>

        {activeOrder && (
          <View style={[styles.activeOrderCard, { borderColor: COLORS.primary }]}>
            <View style={[styles.activeHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.activeTitle}>{isAr ? 'الطلب النشط' : 'Course active'}</Text>
              <View style={styles.activeBadge}>
                <Text style={styles.activeBadgeText}>{activeOrder.id}</Text>
              </View>
            </View>
            <Text style={[styles.activeRoute, { textAlign: isAr ? 'right' : 'left' }]}>{activeOrder.pickup} → {activeOrder.dropoff}</Text>
            <View style={[styles.activeActions, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <TouchableOpacity style={[styles.activeBtn, { backgroundColor: COLORS.primary }]} onPress={() => setActiveOrder({ ...activeOrder, status: activeOrder.status === 'accepted' ? 'picked' : 'delivered' })}>
                <Text style={styles.activeBtnText}>{activeOrder.status === 'accepted' ? (isAr ? 'تم الاستلام' : 'Ramassé') : (isAr ? 'تم التوصيل' : 'Livré')}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.activeBtnOutline}>
                <Ionicons name="navigate" size={16} color={COLORS.primary} />
                <Text style={styles.activeBtnOutlineText}>{isAr ? 'توجيه' : 'Naviguer'}</Text>
              </TouchableOpacity>
            </View>
            {activeOrder.status === 'delivered' && (
              <TouchableOpacity style={{ marginTop: 12, alignItems: 'center' }} onPress={() => setActiveOrder(null)}>
                <Text style={{ color: COLORS.success, fontWeight: '700' }}>{isAr ? 'إنهاء وإغلاق ✓' : 'Terminer ✓'}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        <View style={[styles.sectionHeader, { flexDirection: isAr ? 'row-reverse' : 'row', marginTop: 8 }]}>
          <Text style={styles.sectionTitle}>{t.incomingRequests}</Text>
          <View style={styles.incomingBadge}>
            <Text style={styles.incomingBadgeText}>{incoming.length}</Text>
          </View>
        </View>

        {!isOnline ? (
          <View style={styles.offlineDriverCard}>
            <Ionicons name="power" size={32} color={COLORS.textLight} />
            <Text style={styles.offlineDriverTitle}>{isAr ? 'أنت غير متصل' : 'Vous êtes hors ligne'}</Text>
            <Text style={styles.offlineDriverSub}>{isAr ? 'قم بتفعيل الاتصال لاستقبال الطلبات' : 'Passez en ligne pour recevoir des commandes'}</Text>
          </View>
        ) : (
          incoming.map((order) => (
            <View key={order.id} style={styles.incomingCard}>
              <View style={[styles.incomingHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <Text style={styles.incomingId}>{order.id}</Text>
                <Text style={styles.incomingPrice}>{order.price} {t.dzd}</Text>
              </View>
              <View style={[styles.incomingRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <View style={[styles.incomingCargoIcon, { backgroundColor: CARGO_TYPES.find(c=>c.key===order.cargoType)?.color + '18' }]}>
                  <Ionicons name={CARGO_TYPES.find(c=>c.key===order.cargoType)?.icon as any} size={18} color={CARGO_TYPES.find(c=>c.key===order.cargoType)?.color} />
                </View>
                <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                  <Text style={styles.incomingCargo}>{t.cargo[order.cargoType]} • {order.weight} {t.kg}</Text>
                  <Text style={styles.incomingDistance}>{order.distance} {t.km} • {order.notes || (isAr ? 'بدون ملاحظات' : 'Sans notes')}</Text>
                </View>
                <View style={styles.incomingTime}>
                  <Text style={styles.incomingTimeText}>2 {isAr ? 'د' : 'min'}</Text>
                </View>
              </View>
              <View style={[styles.incomingRouteBox, { alignItems: isAr ? 'flex-end' : 'flex-start' }]}>
                <View style={[styles.incomingRouteRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                  <View style={[styles.dotSmall, { backgroundColor: COLORS.primary }]} />
                  <Text style={styles.incomingRouteText} numberOfLines={1}>{order.pickup}</Text>
                </View>
                <View style={[styles.incomingRouteRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                  <View style={[styles.dotSmall, { backgroundColor: COLORS.accent }]} />
                  <Text style={styles.incomingRouteText} numberOfLines={1}>{order.dropoff}</Text>
                </View>
              </View>
              <View style={[styles.incomingActions, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <TouchableOpacity style={[styles.rejectBtn, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                  <Ionicons name="close" size={16} color={COLORS.textMuted} />
                  <Text style={styles.rejectText}>{t.reject}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.acceptBtn, { flexDirection: isAr ? 'row-reverse' : 'row' }]} onPress={() => handleAccept(order)}>
                  <Ionicons name="checkmark" size={16} color="#fff" />
                  <Text style={styles.acceptText}>{t.accept}</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function AdminDashboardScreen() {
  const { lang, t } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [pricing, setPricing] = useState<PricingConfig>({
    basePrice: 300,
    perKm: 45,
    multipliers: { parcel: 1, goods: 1.2, shop: 1.1, furniture: 1.6, appliance: 1.5, construction: 1.8, personal: 1, other: 1.1 },
  });
  const [editMode, setEditMode] = useState(false);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.adminHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
        <View style={{ alignItems: isAr ? 'flex-end' : 'flex-start' }}>
          <Text style={styles.adminTitle}>{t.dashboard}</Text>
          <Text style={styles.adminSub}>{isAr ? 'القرارة - غرداية • الإدارة' : 'El Guerrara - Admin'}</Text>
        </View>
        <View style={styles.adminBadge}>
          <Ionicons name="shield-checkmark" size={14} color="#fff" />
          <Text style={styles.adminBadgeText}>ADMIN</Text>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 100 }}>
        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: COLORS.primary }]}>
            <Ionicons name="receipt" size={22} color="#fff" />
            <Text style={styles.statValueWhite}>1,248</Text>
            <Text style={styles.statLabelWhite}>{t.totalOrders}</Text>
            <Text style={styles.statTrend}>↑ 12% {isAr ? 'هذا الأسبوع' : 'cette semaine'}</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="bicycle" size={22} color={COLORS.primary} />
            <Text style={styles.statValue}>14</Text>
            <Text style={styles.statLabel}>{t.activeDrivers}</Text>
            <Text style={styles.statTrendGreen}>● {isAr ? 'متصلون الآن' : 'en ligne'}</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="cash" size={22} color={COLORS.accent} />
            <Text style={styles.statValue}>482,500 {t.dzd}</Text>
            <Text style={styles.statLabel}>{t.revenue}</Text>
            <Text style={styles.statTrendGreen}>↑ 8%</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="time" size={22} color={COLORS.info} />
            <Text style={styles.statValue}>18 {isAr ? 'د' : 'min'}</Text>
            <Text style={styles.statLabel}>{t.avgDelivery}</Text>
            <Text style={styles.statTrend}>— {isAr ? 'مستقر' : 'stable'}</Text>
          </View>
        </View>

        {/* Pricing Config */}
        <View style={styles.adminCard}>
          <View style={[styles.adminCardHeader, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.adminCardIcon, { backgroundColor: COLORS.primaryLight }]}>
              <Ionicons name="pricetag" size={18} color={COLORS.primary} />
            </View>
            <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.adminCardTitle}>{t.pricing}</Text>
              <Text style={styles.adminCardSub}>{isAr ? 'قابل للتعديل فورا - يطبق على كل الطلبات الجديدة' : 'Modifiable instantanément'}</Text>
            </View>
            <TouchableOpacity style={[styles.editBtn, editMode && { backgroundColor: COLORS.primary }]} onPress={() => setEditMode(!editMode)}>
              <Ionicons name={editMode ? 'checkmark' : 'create-outline'} size={16} color={editMode ? '#fff' : COLORS.primary} />
              <Text style={[styles.editBtnText, editMode && { color: '#fff' }]}>{editMode ? t.save : (isAr ? 'تعديل' : 'Modifier')}</Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.pricingGrid, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={styles.pricingBox}>
              <Text style={styles.pricingBoxLabel}>{t.basePrice}</Text>
              {editMode ? (
                <TextInput style={styles.pricingBoxInput} value={String(pricing.basePrice)} onChangeText={(v) => setPricing({ ...pricing, basePrice: parseInt(v) || 0 })} keyboardType="numeric" />
              ) : (
                <Text style={styles.pricingBoxValue}>{pricing.basePrice} {t.dzd}</Text>
              )}
            </View>
            <View style={styles.pricingBox}>
              <Text style={styles.pricingBoxLabel}>{t.perKm}</Text>
              {editMode ? (
                <TextInput style={styles.pricingBoxInput} value={String(pricing.perKm)} onChangeText={(v) => setPricing({ ...pricing, perKm: parseInt(v) || 0 })} keyboardType="numeric" />
              ) : (
                <Text style={styles.pricingBoxValue}>{pricing.perKm} {t.dzd}</Text>
              )}
            </View>
          </View>

          <Text style={[styles.multiplierTitle, { textAlign: isAr ? 'right' : 'left' }]}>{t.cargoMultiplier}</Text>
          <View style={styles.multiplierGrid}>
            {CARGO_TYPES.map((c) => (
              <View key={c.key} style={[styles.multiplierChip, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
                <Ionicons name={c.icon as any} size={12} color={c.color} />
                <Text style={styles.multiplierLabel}>{t.cargo[c.key]}</Text>
                {editMode ? (
                  <TextInput
                    style={styles.multiplierInput}
                    value={String(pricing.multipliers[c.key])}
                    onChangeText={(v) => setPricing({ ...pricing, multipliers: { ...pricing.multipliers, [c.key]: parseFloat(v) || 1 } })}
                    keyboardType="decimal-pad"
                  />
                ) : (
                  <Text style={styles.multiplierValue}>×{pricing.multipliers[c.key]}</Text>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* Recent Orders Admin */}
        <View style={styles.adminCard}>
          <Text style={[styles.adminCardTitle, { textAlign: isAr ? 'right' : 'left', marginBottom: 12 }]}>{isAr ? 'الطلبات الأخيرة' : 'Dernières commandes'}</Text>
          {[
            { id: 'WS-49201', cargo: 'مواد بناء', price: 1450, status: 'searching' },
            { id: 'WS-49199', cargo: 'أثاث', price: 980, status: 'delivered' },
            { id: 'WS-49198', cargo: 'طرود', price: 420, status: 'picked' },
          ].map((o) => (
            <View key={o.id} style={[styles.adminOrderRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <Text style={styles.adminOrderId}>{o.id}</Text>
              <Text style={styles.adminOrderCargo}>{o.cargo}</Text>
              <Text style={styles.adminOrderPrice}>{o.price} {t.dzd}</Text>
              <View style={[styles.adminStatusDot, { backgroundColor: o.status === 'delivered' ? COLORS.success : o.status === 'searching' ? COLORS.warning : COLORS.info }]} />
            </View>
          ))}
        </View>

        {/* Drivers Management */}
        <View style={styles.adminCard}>
          <Text style={[styles.adminCardTitle, { textAlign: isAr ? 'right' : 'left', marginBottom: 12 }]}>{t.drivers}</Text>
          {MOCK_DRIVERS.map((d, idx) => (
            <View key={idx} style={[styles.driverRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
              <View style={styles.driverAvatarSmall}>
                <Text style={styles.driverAvatarSmallText}>{d.name.charAt(0)}</Text>
              </View>
              <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
                <Text style={styles.driverRowName}>{d.name}</Text>
                <Text style={styles.driverRowSub}>{d.phone} • {d.triporteur}</Text>
              </View>
              <View style={{ alignItems: isAr ? 'flex-start' : 'flex-end' }}>
                <Text style={styles.driverRowRating}>⭐ {d.rating}</Text>
                <Text style={styles.driverRowTrips}>{d.trips} {isAr ? 'رحلة' : 'courses'}</Text>
              </View>
              <View style={[styles.verifyBadge, { backgroundColor: idx === 1 ? '#FEF3C7' : '#DCFCE7' }]}>
                <Text style={[styles.verifyText, { color: idx === 1 ? '#92400E' : COLORS.success }]}>{idx === 1 ? (isAr ? 'قيد المراجعة' : 'En vérif.') : (isAr ? 'موثق' : 'Vérifié')}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={[styles.offlineCard, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <Ionicons name="cloud-offline" size={20} color={COLORS.primary} />
          <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
            <Text style={styles.offlineCardTitle}>{isAr ? 'تحمل انقطاع الإنترنت' : 'Résilience hors ligne'}</Text>
            <Text style={styles.offlineCardSub}>{isAr ? 'جميع الطلبات محفوظة محليا عبر AsyncStorage وتتم مزامنتها عند عودة الاتصال - Supabase offline queue' : 'Toutes les commandes sauvegardées localement et synchronisées à la reconnexion'}</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ProfileScreen() {
  const { lang, t, toggle } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  const [isOffline, setIsOffline] = useState(false);
  const [role, setRole] = useState<Role>('customer');

  useEffect(() => {
    AsyncStorage.getItem('wassilha_role').then((r) => r && setRole(r as Role));
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 100 }}>
        <View style={styles.profileHeader}>
          <View style={styles.profileAvatar}>
            <Text style={styles.profileAvatarText}>م</Text>
            <View style={styles.profileVerified}>
              <Ionicons name="checkmark" size={12} color="#fff" />
            </View>
          </View>
          <Text style={styles.profileName}>{isAr ? 'محمد الزبون' : 'Mohamed Client'}</Text>
          <Text style={styles.profilePhone}>+213 5XX XX XX XX • {isAr ? 'القرارة' : 'El Guerrara'}</Text>
          <View style={[styles.profileRoles, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            {(['customer', 'driver', 'admin'] as Role[]).map((r) => (
              <TouchableOpacity key={r} onPress={async () => { setRole(r); await AsyncStorage.setItem('wassilha_role', r); }} style={[styles.profileRoleChip, role === r && styles.profileRoleChipActive]}>
                <Text style={[styles.profileRoleText, role === r && styles.profileRoleTextActive]}>{r === 'customer' ? t.customer : r === 'driver' ? t.driver : t.admin}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.profileCard}>
          <Text style={[styles.profileCardTitle, { textAlign: isAr ? 'right' : 'left' }]}>{t.language}</Text>
          <View style={[styles.langRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <TouchableOpacity style={[styles.langOption, lang === 'ar' && styles.langOptionActive, { flexDirection: isAr ? 'row-reverse' : 'row' }]} onPress={() => lang !== 'ar' && toggle()}>
              <Text style={styles.langFlag}>🇩🇿</Text>
              <Text style={[styles.langOptionText, lang === 'ar' && styles.langOptionTextActive]}>{t.arabic} (RTL)</Text>
              {lang === 'ar' && <Ionicons name="checkmark-circle" size={18} color={COLORS.primary} />}
            </TouchableOpacity>
            <TouchableOpacity style={[styles.langOption, lang === 'fr' && styles.langOptionActive, { flexDirection: isAr ? 'row-reverse' : 'row' }]} onPress={() => lang !== 'fr' && toggle()}>
              <Text style={styles.langFlag}>🇫🇷</Text>
              <Text style={[styles.langOptionText, lang === 'fr' && styles.langOptionTextActive]}>{t.french}</Text>
              {lang === 'fr' && <Ionicons name="checkmark-circle" size={18} color={COLORS.primary} />}
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.profileCard}>
          <View style={[styles.profileRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.profileIcon, { backgroundColor: '#E6F4F1' }]}>
              <Ionicons name="cloud-offline-outline" size={18} color={COLORS.primary} />
            </View>
            <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.profileRowTitle}>{t.offlineMode}</Text>
              <Text style={styles.profileRowSub}>{t.offlineDesc}</Text>
            </View>
            <Switch value={isOffline} onValueChange={setIsOffline} trackColor={{ true: COLORS.primary, false: '#E2E8F0' }} />
          </View>
          <View style={styles.divider} />
          <View style={[styles.profileRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.profileIcon, { backgroundColor: '#FFF1E0' }]}>
              <Ionicons name="cash-outline" size={18} color={COLORS.accent} />
            </View>
            <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.profileRowTitle}>{isAr ? 'العملة' : 'Devise'}</Text>
              <Text style={styles.profileRowSub}>DZD • {isAr ? 'الدينار الجزائري' : 'Dinar Algérien'}</Text>
            </View>
            <Text style={styles.profileValue}>دج</Text>
          </View>
          <View style={styles.divider} />
          <View style={[styles.profileRow, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={[styles.profileIcon, { backgroundColor: '#EFF6FF' }]}>
              <Ionicons name="time-outline" size={18} color={COLORS.info} />
            </View>
            <View style={{ flex: 1, alignItems: isAr ? 'flex-end' : 'flex-start' }}>
              <Text style={styles.profileRowTitle}>{isAr ? 'التوقيت المحلي' : 'Fuseau horaire'}</Text>
              <Text style={styles.profileRowSub}>Africa/Algiers • UTC+1</Text>
            </View>
            <Text style={styles.profileValue}>UTC+1</Text>
          </View>
        </View>

        <View style={styles.profileCard}>
          <View style={[styles.techStack, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
            <View style={styles.techBadge}><Text style={styles.techBadgeText}>Flutter</Text></View>
            <View style={styles.techBadge}><Text style={styles.techBadgeText}>Supabase</Text></View>
            <View style={styles.techBadge}><Text style={styles.techBadgeText}>Mapbox</Text></View>
            <View style={styles.techBadge}><Text style={styles.techBadgeText}>Dart</Text></View>
            <View style={styles.techBadge}><Text style={styles.techBadgeText}>Material 3</Text></View>
          </View>
          <Text style={[styles.techDesc, { textAlign: isAr ? 'right' : 'left' }]}>
            {isAr ? 'التطبيق مبني وفق معايير Material 3 مع تشفير بيانات، مصادقة OTP، خرائط حية، وقائمة انتظار للعمل دون إنترنت.' : 'App construite en Material 3 avec chiffrement, auth OTP, cartes live et file d\'attente offline.'}
          </Text>
        </View>

        <TouchableOpacity style={[styles.logoutBtn, { flexDirection: isAr ? 'row-reverse' : 'row' }]}>
          <Ionicons name="log-out-outline" size={18} color={COLORS.error} />
          <Text style={styles.logoutText}>{t.logout}</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>WASSILHA v1.0.0 • {isAr ? 'القرارة - غرداية - الجزائر' : 'El Guerrara - Ghardaïa - Algérie'} • © 2026</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

// === TAB NAVIGATORS ===
function CustomerTabs() {
  const { t, lang } = useContext(LanguageContext);
  const isAr = lang === 'ar';
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textLight,
        tabBarStyle: { height: 64, paddingBottom: 8, paddingTop: 8, backgroundColor: '#fff', borderTopColor: COLORS.border },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      }}
    >
      <Tab.Screen
        name="CustomerHome"
        component={CustomerHomeScreen}
        options={{
          title: t.home,
          tabBarIcon: ({ color, size }) => <Ionicons name="home" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="History"
        component={OrdersHistoryScreen}
        options={{
          title: t.history,
          tabBarIcon: ({ color, size }) => <Ionicons name="receipt" size={size} color={color} />,
          tabBarBadge: 3,
        }}
      />
      <Tab.Screen
        name="TrackTab"
        component={TrackingScreen}
        options={{
          title: t.track,
          tabBarIcon: ({ color, size }) => <Ionicons name="navigate-circle" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          title: t.profile,
          tabBarIcon: ({ color, size }) => <Ionicons name="person" size={size} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

function DriverTabs() {
  const { t } = useContext(LanguageContext);
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textLight,
        tabBarStyle: { height: 64, paddingBottom: 8, paddingTop: 8, backgroundColor: '#fff', borderTopColor: COLORS.border },
      }}
    >
      <Tab.Screen name="DriverHome" component={DriverHomeScreen} options={{ title: t.home, tabBarIcon: ({ color, size }) => <Ionicons name="bicycle" size={size} color={color} /> }} />
      <Tab.Screen name="DriverOrders" component={OrdersHistoryScreen} options={{ title: t.myTrips, tabBarIcon: ({ color, size }) => <Ionicons name="list" size={size} color={color} /> }} />
      <Tab.Screen name="DriverEarnings" component={AdminDashboardScreen} options={{ title: t.earnings, tabBarIcon: ({ color, size }) => <Ionicons name="wallet" size={size} color={color} /> }} />
      <Tab.Screen name="DriverProfile" component={ProfileScreen} options={{ title: t.profile, tabBarIcon: ({ color, size }) => <Ionicons name="person" size={size} color={color} /> }} />
    </Tab.Navigator>
  );
}

function AdminTabs() {
  const { t } = useContext(LanguageContext);
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textLight,
        tabBarStyle: { height: 64, paddingBottom: 8, paddingTop: 8, backgroundColor: '#0F172A', borderTopColor: '#1E293B' },
        tabBarActiveBackgroundColor: '#1E293B',
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
      }}
    >
      <Tab.Screen name="AdminDash" component={AdminDashboardScreen} options={{ title: t.dashboard, tabBarIcon: ({ color, size }) => <Ionicons name="grid" size={size} color={color} /> }} />
      <Tab.Screen name="AdminPricing" component={AdminDashboardScreen} options={{ title: t.pricing, tabBarIcon: ({ color, size }) => <Ionicons name="pricetag" size={size} color={color} /> }} />
      <Tab.Screen name="AdminOrders" component={OrdersHistoryScreen} options={{ title: t.orders, tabBarIcon: ({ color, size }) => <Ionicons name="receipt" size={size} color={color} /> }} />
      <Tab.Screen name="AdminProfile" component={ProfileScreen} options={{ title: t.admin, tabBarIcon: ({ color, size }) => <Ionicons name="shield-checkmark" size={size} color={color} /> }} />
    </Tab.Navigator>
  );
}

function MainNavigator({ route }: any) {
  const [role, setRole] = useState<Role>(route?.params?.role || 'customer');
  const { lang } = useContext(LanguageContext);

  useEffect(() => {
    const check = async () => {
      const r = await AsyncStorage.getItem('wassilha_role');
      if (r) setRole(r as Role);
    };
    check();
    const interval = setInterval(check, 1000);
    return () => clearInterval(interval);
  }, []);

  // Role switcher bar
  const RoleSwitcher = () => (
    <View style={[styles.roleSwitcherBar, { flexDirection: lang === 'ar' ? 'row-reverse' : 'row' }]}>
      <Text style={styles.roleSwitcherLabel}>{lang === 'ar' ? 'تجربة الأدوار:' : 'Rôles:'}</Text>
      {(['customer', 'driver', 'admin'] as Role[]).map((r) => (
        <TouchableOpacity
          key={r}
          onPress={async () => {
            setRole(r);
            await AsyncStorage.setItem('wassilha_role', r);
          }}
          style={[styles.roleSwitcherBtn, role === r && styles.roleSwitcherBtnActive]}
        >
          <Text style={[styles.roleSwitcherText, role === r && styles.roleSwitcherTextActive]}>
            {r === 'customer' ? (lang === 'ar' ? 'زبون' : 'Client') : r === 'driver' ? (lang === 'ar' ? 'سائق' : 'Chauffeur') : 'Admin'}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <RoleSwitcher />
      {role === 'customer' && <CustomerTabs />}
      {role === 'driver' && <DriverTabs />}
      {role === 'admin' && <AdminTabs />}
    </View>
  );
}

// === APP ROOT ===
export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const [lang, setLang] = useState<'ar' | 'fr'>('ar');

  const toggle = () => setLang((p) => (p === 'ar' ? 'fr' : 'ar'));
  const t = translations[lang];

  if (!fontsLoaded) return null;

  const navTheme = {
    ...DefaultTheme,
    colors: { ...DefaultTheme.colors, background: COLORS.background, primary: COLORS.primary },
  };

  return (
    <SafeAreaProvider>
      <LanguageContext.Provider value={{ lang, toggle, t }}>
        <NavigationContainer theme={navTheme}>
          <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
            <Stack.Screen name="Onboarding" component={OnboardingScreen} />
            <Stack.Screen name="Auth" component={AuthScreen} />
            <Stack.Screen name="Main" component={MainNavigator} />
            <Stack.Screen name="Tracking" component={TrackingScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </LanguageContext.Provider>
    </SafeAreaProvider>
  );
}

// === STYLES ===
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  // Onboarding
  decoCircle: { position: 'absolute', backgroundColor: '#fff', borderRadius: 200 },
  onboardingHeader: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoBox: { width: 52, height: 52, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 12, elevation: 4 },
  logoText: { fontSize: 20, fontWeight: '900', color: '#fff', letterSpacing: 0.5 },
  logoSub: { fontSize: 10, color: 'rgba(255,255,255,0.85)', fontWeight: '700', letterSpacing: 1 },
  badgeLive: { marginLeft: 8, backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  liveDotSmall: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#22C55E' },
  badgeLiveText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  langToggleTop: { flexDirection: 'row', backgroundColor: 'rgba(0,0,0,0.15)', borderRadius: 20, padding: 3, gap: 2 },
  langBtn: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 14 },
  langBtnActive: { backgroundColor: '#fff' },
  langBtnText: { fontSize: 12, fontWeight: '800', color: 'rgba(255,255,255,0.9)' },
  langBtnTextActive: { color: COLORS.primary },
  onboardingCard: { margin: 16, backgroundColor: '#fff', borderRadius: 24, padding: 20, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 20, elevation: 8 },
  illustrationWrap: { alignItems: 'center', marginBottom: 16 },
  illustrationBg: { width: 160, height: 120, backgroundColor: COLORS.primaryLight, borderRadius: 20, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  boxOnBike: { position: 'absolute', top: 24, backgroundColor: COLORS.accent, width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  floatBadge: { position: 'absolute', backgroundColor: '#fff', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 4, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, elevation: 3, borderWidth: 1, borderColor: COLORS.border },
  floatBadgeText: { fontSize: 11, fontWeight: '700', color: COLORS.text },
  onboardingTitle: { fontSize: 22, fontWeight: '900', color: COLORS.text, marginBottom: 8 },
  onboardingSub: { fontSize: 13, color: COLORS.textMuted, lineHeight: 20, marginBottom: 16 },
  featuresRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20, gap: 8 },
  featureItem: { alignItems: 'center', gap: 6, flex: 1 },
  featureIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  featureLabel: { fontSize: 11, fontWeight: '600', color: COLORS.textMuted, textAlign: 'center' },
  primaryBtn: { backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 14, shadowColor: COLORS.primary, shadowOpacity: 0.25, shadowRadius: 10, elevation: 4 },
  primaryBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  secureRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 12, flexWrap: 'wrap' },
  secureText: { fontSize: 11, color: COLORS.textMuted, fontWeight: '500' },
  secureDot: { color: COLORS.textLight },
  regionNote: { textAlign: 'center', fontSize: 11, color: COLORS.textLight, marginTop: 10, fontStyle: 'italic' },
  bottomTech: { alignItems: 'center', paddingBottom: 12, paddingTop: 4 },
  techText: { color: 'rgba(255,255,255,0.6)', fontSize: 10, letterSpacing: 1, fontWeight: '600' },
  // Auth
  authContainer: { padding: 20, gap: 16 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.border },
  authLogo: { alignItems: 'center', gap: 6, marginTop: 8 },
  authTitle: { fontSize: 28, fontWeight: '900', color: COLORS.primary, marginTop: 8 },
  authSub: { fontSize: 13, color: COLORS.textMuted, textAlign: 'center' },
  roleSelector: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 14, padding: 4, gap: 4, borderWidth: 1, borderColor: COLORS.border },
  roleChip: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: 10 },
  roleChipActive: { backgroundColor: COLORS.primary },
  roleChipText: { fontSize: 12, fontWeight: '700', color: COLORS.textMuted },
  roleChipTextActive: { color: '#fff' },
  roleHint: { textAlign: 'center', fontSize: 11, color: COLORS.textLight },
  authCard: { backgroundColor: '#fff', borderRadius: 20, padding: 20, borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 12, elevation: 2 },
  authCardTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text },
  authCardSub: { fontSize: 13, color: COLORS.textMuted, marginTop: 4, marginBottom: 16 },
  phoneInputRow: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  countryCode: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.background, paddingHorizontal: 12, paddingVertical: 14, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border },
  countryFlag: { fontSize: 16 },
  countryCodeText: { fontWeight: '700', color: COLORS.text },
  phoneInput: { flex: 1, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14, fontSize: 16, fontWeight: '600', color: COLORS.text },
  otpInfo: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 12, backgroundColor: '#EFF6FF', padding: 8, borderRadius: 10 },
  otpInfoText: { fontSize: 12, color: COLORS.info, fontWeight: '600' },
  otpRow: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 8 },
  otpInput: { width: 56, height: 56, borderRadius: 14, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.background, fontSize: 20, fontWeight: '800', color: COLORS.text },
  otpInputFilled: { borderColor: COLORS.primary, backgroundColor: COLORS.primaryLight },
  resendBtn: { alignItems: 'center', marginTop: 16 },
  resendText: { color: COLORS.primary, fontWeight: '700', fontSize: 13 },
  // Customer header
  customerHeader: { backgroundColor: '#fff', paddingHorizontal: 16, paddingVertical: 12, alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  headerLeft: { alignItems: 'center', gap: 10 },
  logoBoxSmall: { width: 40, height: 40, borderRadius: 10, backgroundColor: COLORS.primaryLight, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 16, fontWeight: '900', color: COLORS.text, letterSpacing: 0.5 },
  locationRow: { alignItems: 'center', gap: 4, marginTop: 2 },
  headerLocation: { fontSize: 12, color: COLORS.textMuted, fontWeight: '600' },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.success, marginLeft: 4 },
  headerActions: { alignItems: 'center', gap: 8 },
  headerIconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.border },
  headerLang: { fontSize: 12, fontWeight: '800', color: COLORS.primary },
  avatarBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontWeight: '800' },
  offlineBanner: { backgroundColor: COLORS.error, paddingHorizontal: 16, paddingVertical: 8, alignItems: 'center', gap: 8, justifyContent: 'center' },
  offlineText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  // Map
  mapContainer: { height: 200, margin: 16, borderRadius: 16, overflow: 'hidden', backgroundColor: '#E2E8F0', borderWidth: 1, borderColor: COLORS.border, position: 'relative' },
  mapGrid: { flex: 1, backgroundColor: '#F8FAF9', position: 'relative' },
  roadH: { position: 'absolute', left: 0, right: 0, height: 14, backgroundColor: '#CBD5E1', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#94A3B8' },
  roadV: { position: 'absolute', top: 0, bottom: 0, width: 14, backgroundColor: '#CBD5E1', borderLeftWidth: 1, borderRightWidth: 1, borderColor: '#94A3B8' },
  mapBlock: { position: 'absolute', width: '32%', height: '22%', borderRadius: 6, borderWidth: 1, borderColor: '#E2E8F0' },
  mapPin: { position: 'absolute', width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 6, elevation: 4, borderWidth: 2, borderColor: '#fff' },
  dashedPath: { position: 'absolute', top: '42%', left: '30%', width: '40%', height: 2, backgroundColor: COLORS.primary, opacity: 0.5, borderStyle: 'dashed' },
  distanceBadge: { position: 'absolute', bottom: 8, left: 8, backgroundColor: '#fff', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 4, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, elevation: 2 },
  distanceText: { fontSize: 11, fontWeight: '700', color: COLORS.text },
  mapTopOverlay: { position: 'absolute', top: 10, left: 10, right: 10, flexDirection: 'row', gap: 8 },
  mapSearchBar: { flex: 1, backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 8, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, elevation: 3 },
  mapSearchText: { flex: 1, fontSize: 12, fontWeight: '600', color: COLORS.text },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.error },
  liveText: { fontSize: 10, fontWeight: '900', color: COLORS.error, letterSpacing: 0.5 },
  mapLocateBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, elevation: 3 },
  mapAttribution: { position: 'absolute', bottom: 6, right: 8, backgroundColor: 'rgba(255,255,255,0.9)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  mapAttrText: { fontSize: 9, color: COLORS.textMuted },
  // Locations card
  locationsCard: { marginHorizontal: 16, backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 10, elevation: 2, gap: 12 },
  locationsTimeline: { flexDirection: 'row', gap: 12 },
  timelineDotWrap: { alignItems: 'center', paddingTop: 6, gap: 4 },
  timelineDot: { width: 10, height: 10, borderRadius: 5, borderWidth: 2, borderColor: '#fff', shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 4, elevation: 2 },
  timelineLine: { width: 2, flex: 1, backgroundColor: COLORS.border, borderRadius: 1, minHeight: 40 },
  locationInput: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.background, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: COLORS.border, gap: 10 },
  locationLabel: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  locationValue: { fontSize: 13, fontWeight: '700', color: COLORS.text, marginTop: 2 },
  locationIcon: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  swapBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center', alignSelf: 'center' },
  locationActions: { flexDirection: 'row', gap: 8 },
  locActionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: COLORS.primaryLight, paddingVertical: 10, borderRadius: 10, borderWidth: 1, borderColor: COLORS.primary + '20' },
  locActionText: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  // Cargo
  section: { paddingHorizontal: 16, paddingTop: 16 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionTitle: { fontSize: 15, fontWeight: '800', color: COLORS.text },
  sectionSub: { fontSize: 12, color: COLORS.textMuted },
  cargoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cargoCard: { width: (width - 16 * 2 - 10 * 3) / 4, backgroundColor: '#fff', borderRadius: 14, padding: 10, alignItems: 'center', gap: 6, borderWidth: 1.5, borderColor: COLORS.border, position: 'relative' },
  cargoCardSelected: { backgroundColor: COLORS.primaryLight, shadowColor: COLORS.primary, shadowOpacity: 0.15, shadowRadius: 8, elevation: 3 },
  cargoCheck: { position: 'absolute', top: 6, right: 6, width: 16, height: 16, borderRadius: 8, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  cargoIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  cargoLabel: { fontSize: 11, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  cargoDesc: { fontSize: 9, color: COLORS.textMuted, textAlign: 'center' },
  // Weight
  weightBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: COLORS.primaryLight, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 },
  weightBadgeText: { fontSize: 12, fontWeight: '800', color: COLORS.primary },
  weightRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  weightBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  weightSliderWrap: { flex: 1, gap: 6 },
  weightTrack: { height: 8, backgroundColor: COLORS.border, borderRadius: 4, position: 'relative' },
  weightFill: { height: '100%', backgroundColor: COLORS.primary, borderRadius: 4 },
  weightThumb: { position: 'absolute', top: -6, width: 20, height: 20, borderRadius: 10, backgroundColor: COLORS.primary, borderWidth: 3, borderColor: '#fff', shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 4, elevation: 3, marginLeft: -10 },
  weightLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  weightLabel: { fontSize: 11, color: COLORS.textMuted },
  weightPresets: { flexDirection: 'row', gap: 8, marginTop: 10 },
  weightPreset: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, paddingVertical: 8, borderRadius: 10, alignItems: 'center' },
  weightPresetActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  weightPresetText: { fontSize: 12, fontWeight: '700', color: COLORS.textMuted },
  weightPresetTextActive: { color: '#fff' },
  notesInputWrap: { backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, padding: 12, paddingTop: 12, minHeight: 70 },
  notesInput: { fontSize: 13, color: COLORS.text, minHeight: 40, paddingRight: 30 },
  priceCard: { margin: 16, backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 12, elevation: 2, gap: 12 },
  priceHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  priceIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  priceTitle: { fontSize: 14, fontWeight: '800', color: COLORS.text },
  priceSub: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', backgroundColor: COLORS.background, padding: 12, borderRadius: 12 },
  priceValue: { fontSize: 22, fontWeight: '900', color: COLORS.primary },
  priceVat: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  priceBreakdown: { alignItems: 'flex-end' },
  priceBreakText: { fontSize: 10, color: COLORS.textMuted, maxWidth: 140, textAlign: 'right' },
  priceFeatures: { flexDirection: 'row', gap: 16 },
  priceFeature: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  priceFeatureText: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  primaryBtnLarge: { marginHorizontal: 16, backgroundColor: COLORS.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 16, borderRadius: 14, shadowColor: COLORS.primary, shadowOpacity: 0.3, shadowRadius: 12, elevation: 4 },
  primaryBtnLargeText: { color: '#fff', fontSize: 16, fontWeight: '900' },
  pricePill: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)' },
  pricePillText: { color: '#fff', fontSize: 12, fontWeight: '800' },
  offlineNote: { textAlign: 'center', fontSize: 11, color: COLORS.textMuted, marginTop: 10, paddingHorizontal: 16 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, gap: 16 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  modalTitle: { fontSize: 16, fontWeight: '800', color: COLORS.text },
  modalSub: { fontSize: 12, color: COLORS.textMuted },
  pricingEditRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: COLORS.background, padding: 12, borderRadius: 12 },
  pricingLabel: { flex: 1, fontSize: 13, fontWeight: '600', color: COLORS.text },
  pricingInput: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, minWidth: 80, textAlign: 'center', fontWeight: '700' },
  pricingUnit: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  // Tracking
  trackHeader: { backgroundColor: '#fff', padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backCircle: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.border },
  trackTitle: { fontSize: 16, fontWeight: '800', color: COLORS.text },
  trackId: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  statusBadgeText: { color: '#fff', fontSize: 11, fontWeight: '800' },
  trackCard: { margin: 16, backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, gap: 16, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 10, elevation: 2 },
  searchingBox: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#FFFBEB', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: '#FDE68A' },
  searchingTitle: { fontSize: 14, fontWeight: '800', color: COLORS.text },
  searchingSub: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  driverFoundBox: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: COLORS.primaryLight, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: COLORS.primary + '30' },
  driverAvatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  driverAvatarText: { color: '#fff', fontSize: 18, fontWeight: '900' },
  driverOnlineDot: { position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: 6, backgroundColor: COLORS.success, borderWidth: 2, borderColor: '#fff' },
  driverFoundTitle: { fontSize: 12, color: COLORS.success, fontWeight: '800' },
  driverName: { fontSize: 14, fontWeight: '800', color: COLORS.text, marginTop: 2 },
  driverTri: { fontSize: 11, color: COLORS.textMuted },
  driverActions: { flexDirection: 'row', gap: 8 },
  driverActionBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  timeline: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  timelineStep: { flex: 1, alignItems: 'center', gap: 6, position: 'relative' },
  timelineCircle: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  timelineCircleDone: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  timelineCircleCurrent: { borderWidth: 3, borderColor: COLORS.primary, borderStyle: 'solid' },
  timelineLabel: { fontSize: 9, color: COLORS.textMuted, textAlign: 'center', fontWeight: '600' },
  timelineLabelDone: { color: COLORS.primary, fontWeight: '700' },
  timelineConnector: { position: 'absolute', top: 14, left: '60%', right: '-40%', height: 2, backgroundColor: COLORS.border },
  orderDetailBox: { backgroundColor: COLORS.background, borderRadius: 12, padding: 12, gap: 8 },
  orderDetailRow: { flexDirection: 'row', justifyContent: 'space-between' },
  orderDetailLabel: { fontSize: 12, color: COLORS.textMuted },
  orderDetailValue: { fontSize: 12, fontWeight: '700', color: COLORS.text, maxWidth: '60%', textAlign: 'right' },
  deliveredCelebrate: { alignItems: 'center', gap: 8, paddingVertical: 12 },
  deliveredTitle: { fontSize: 18, fontWeight: '900', color: COLORS.success },
  deliveredSub: { fontSize: 13, color: COLORS.textMuted },
  etaBox: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EFF6FF', padding: 10, borderRadius: 10, justifyContent: 'center' },
  etaText: { fontSize: 12, fontWeight: '700', color: COLORS.info, flex: 1, textAlign: 'center' },
  etaLive: { backgroundColor: COLORS.error, color: '#fff', fontSize: 10, fontWeight: '900', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, overflow: 'hidden' },
  // History
  pageHeader: { backgroundColor: '#fff', padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  pageTitle: { fontSize: 18, fontWeight: '900', color: COLORS.text },
  pageBadge: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, flexDirection: 'row', alignItems: 'center' },
  pageBadgeText: { color: COLORS.primary, fontSize: 12, fontWeight: '800' },
  emptyState: { alignItems: 'center', paddingVertical: 40, gap: 8 },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: COLORS.textMuted },
  emptySub: { fontSize: 13, color: COLORS.textLight },
  orderCard: { backgroundColor: '#fff', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: COLORS.border, gap: 8 },
  orderCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderId: { fontSize: 13, fontWeight: '800', color: COLORS.text },
  orderStatus: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 },
  orderStatusText: { fontSize: 11, fontWeight: '800' },
  orderCardRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  orderCargoIcon: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  orderCargoText: { flex: 1, fontSize: 12, fontWeight: '600', color: COLORS.text },
  orderPrice: { fontSize: 14, fontWeight: '900', color: COLORS.primary },
  orderRoute: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  orderRouteText: { fontSize: 11, color: COLORS.textMuted, flex: 1 },
  orderDate: { fontSize: 11, color: COLORS.textLight },
  // Driver
  driverHeader: { backgroundColor: '#fff', padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  driverHeaderTitle: { fontSize: 18, fontWeight: '900', color: COLORS.text },
  driverHeaderSub: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  onlineToggle: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border },
  onlineText: { fontSize: 12, fontWeight: '800' },
  driverStats: { flexDirection: 'row', gap: 10 },
  driverStatCard: { flex: 1, backgroundColor: '#fff', borderRadius: 14, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border, gap: 4 },
  driverStatValue: { fontSize: 16, fontWeight: '900', color: COLORS.text },
  driverStatLabel: { fontSize: 11, color: COLORS.textMuted, textAlign: 'center' },
  activeOrderCard: { backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1.5, gap: 10, shadowColor: COLORS.primary, shadowOpacity: 0.08, shadowRadius: 10, elevation: 3 },
  activeHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  activeTitle: { fontSize: 14, fontWeight: '800', color: COLORS.primary },
  activeBadge: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 },
  activeBadgeText: { fontSize: 11, fontWeight: '800', color: COLORS.primary },
  activeRoute: { fontSize: 13, fontWeight: '600', color: COLORS.text },
  activeActions: { flexDirection: 'row', gap: 10 },
  activeBtn: { flex: 1, paddingVertical: 12, borderRadius: 10, alignItems: 'center' },
  activeBtnText: { color: '#fff', fontWeight: '800' },
  activeBtnOutline: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1, borderColor: COLORS.primary, paddingVertical: 12, borderRadius: 10 },
  activeBtnOutlineText: { color: COLORS.primary, fontWeight: '700' },
  offlineDriverCard: { backgroundColor: '#fff', borderRadius: 16, padding: 24, alignItems: 'center', gap: 8, borderWidth: 1, borderColor: COLORS.border },
  offlineDriverTitle: { fontSize: 16, fontWeight: '800', color: COLORS.text },
  offlineDriverSub: { fontSize: 13, color: COLORS.textMuted, textAlign: 'center' },
  incomingBadge: { backgroundColor: COLORS.accent, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20 },
  incomingBadgeText: { color: '#fff', fontSize: 12, fontWeight: '800' },
  incomingCard: { backgroundColor: '#fff', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border, gap: 10, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 8, elevation: 1 },
  incomingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  incomingId: { fontSize: 13, fontWeight: '800', color: COLORS.text },
  incomingPrice: { fontSize: 16, fontWeight: '900', color: COLORS.primary },
  incomingRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  incomingCargoIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  incomingCargo: { fontSize: 13, fontWeight: '700', color: COLORS.text },
  incomingDistance: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  incomingTime: { backgroundColor: COLORS.background, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 10, borderWidth: 1, borderColor: COLORS.border },
  incomingTimeText: { fontSize: 11, fontWeight: '800', color: COLORS.textMuted },
  incomingRouteBox: { backgroundColor: COLORS.background, padding: 10, borderRadius: 10, gap: 6 },
  incomingRouteRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dotSmall: { width: 8, height: 8, borderRadius: 4 },
  incomingRouteText: { fontSize: 12, color: COLORS.text, flex: 1 },
  incomingActions: { flexDirection: 'row', gap: 10 },
  rejectBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1, borderColor: COLORS.border, paddingVertical: 10, borderRadius: 10, backgroundColor: '#fff' },
  rejectText: { fontSize: 13, fontWeight: '700', color: COLORS.textMuted },
  acceptBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: COLORS.primary, paddingVertical: 10, borderRadius: 10 },
  acceptText: { color: '#fff', fontWeight: '800' },
  // Admin
  adminHeader: { backgroundColor: COLORS.darkBg, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  adminTitle: { fontSize: 18, fontWeight: '900', color: '#fff' },
  adminSub: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  adminBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: COLORS.primary, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  adminBadgeText: { color: '#fff', fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard: { width: (width - 16 * 2 - 10) / 2, backgroundColor: '#fff', borderRadius: 16, padding: 14, gap: 6, borderWidth: 1, borderColor: COLORS.border },
  statValue: { fontSize: 18, fontWeight: '900', color: COLORS.text },
  statValueWhite: { fontSize: 18, fontWeight: '900', color: '#fff' },
  statLabel: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  statLabelWhite: { fontSize: 11, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },
  statTrend: { fontSize: 11, color: COLORS.textLight },
  statTrendGreen: { fontSize: 11, color: COLORS.success, fontWeight: '700' },
  adminCard: { backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  adminCardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  adminCardIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  adminCardTitle: { fontSize: 14, fontWeight: '800', color: COLORS.text },
  adminCardSub: { fontSize: 11, color: COLORS.textMuted },
  editBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: COLORS.primary, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  editBtnText: { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  pricingGrid: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  pricingBox: { flex: 1, backgroundColor: COLORS.background, borderRadius: 12, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  pricingBoxLabel: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  pricingBoxValue: { fontSize: 16, fontWeight: '900', color: COLORS.primary, marginTop: 4 },
  pricingBoxInput: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.primary, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, fontSize: 16, fontWeight: '800', color: COLORS.primary, textAlign: 'center', marginTop: 4, minWidth: 80 },
  multiplierTitle: { fontSize: 12, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  multiplierGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  multiplierChip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: COLORS.background, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border },
  multiplierLabel: { fontSize: 11, fontWeight: '600', color: COLORS.text },
  multiplierValue: { fontSize: 11, fontWeight: '800', color: COLORS.primary, marginLeft: 4 },
  multiplierInput: { backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.primary, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2, minWidth: 36, textAlign: 'center', fontSize: 11, fontWeight: '800' },
  adminOrderRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.background },
  adminOrderId: { fontSize: 12, fontWeight: '700', color: COLORS.text, flex: 1 },
  adminOrderCargo: { fontSize: 12, color: COLORS.textMuted, flex: 1, textAlign: 'center' },
  adminOrderPrice: { fontSize: 12, fontWeight: '800', color: COLORS.primary },
  adminStatusDot: { width: 8, height: 8, borderRadius: 4 },
  driverRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.background },
  driverAvatarSmall: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.primaryLight, alignItems: 'center', justifyContent: 'center' },
  driverAvatarSmallText: { color: COLORS.primary, fontWeight: '800' },
  driverRowName: { fontSize: 13, fontWeight: '700', color: COLORS.text },
  driverRowSub: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  driverRowRating: { fontSize: 12, fontWeight: '700', color: COLORS.text },
  driverRowTrips: { fontSize: 11, color: COLORS.textMuted },
  verifyBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 },
  verifyText: { fontSize: 10, fontWeight: '800' },
  offlineCard: { flexDirection: 'row', gap: 10, backgroundColor: COLORS.primaryLight, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: COLORS.primary + '20', alignItems: 'flex-start' },
  offlineCardTitle: { fontSize: 13, fontWeight: '800', color: COLORS.primary },
  offlineCardSub: { fontSize: 11, color: COLORS.textMuted, marginTop: 2, lineHeight: 16 },
  // Profile
  profileHeader: { backgroundColor: '#fff', borderRadius: 16, padding: 20, alignItems: 'center', gap: 6, borderWidth: 1, borderColor: COLORS.border },
  profileAvatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  profileAvatarText: { color: '#fff', fontSize: 28, fontWeight: '900' },
  profileVerified: { position: 'absolute', bottom: 0, right: 0, width: 22, height: 22, borderRadius: 11, backgroundColor: COLORS.success, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  profileName: { fontSize: 18, fontWeight: '900', color: COLORS.text, marginTop: 8 },
  profilePhone: { fontSize: 12, color: COLORS.textMuted },
  profileRoles: { flexDirection: 'row', gap: 8, marginTop: 8 },
  profileRoleChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border, backgroundColor: '#fff' },
  profileRoleChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  profileRoleText: { fontSize: 11, fontWeight: '700', color: COLORS.textMuted },
  profileRoleTextActive: { color: '#fff' },
  profileCard: { backgroundColor: '#fff', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, gap: 12 },
  profileCardTitle: { fontSize: 14, fontWeight: '800', color: COLORS.text },
  langRow: { flexDirection: 'row', gap: 10 },
  langOption: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.background },
  langOptionActive: { backgroundColor: COLORS.primaryLight, borderColor: COLORS.primary },
  langFlag: { fontSize: 18 },
  langOptionText: { flex: 1, fontSize: 13, fontWeight: '600', color: COLORS.text },
  langOptionTextActive: { color: COLORS.primary },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  profileIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  profileRowTitle: { fontSize: 13, fontWeight: '700', color: COLORS.text },
  profileRowSub: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  profileValue: { fontSize: 13, fontWeight: '800', color: COLORS.primary },
  divider: { height: 1, backgroundColor: COLORS.border },
  techStack: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  techBadge: { backgroundColor: COLORS.darkBg, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  techBadgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  techDesc: { fontSize: 12, color: COLORS.textMuted, lineHeight: 18 },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#fff', borderWidth: 1, borderColor: '#FECACA', paddingVertical: 14, borderRadius: 12 },
  logoutText: { color: COLORS.error, fontWeight: '800' },
  versionText: { textAlign: 'center', fontSize: 11, color: COLORS.textLight, marginTop: 4 },
  roleSwitcherBar: { backgroundColor: COLORS.darkBg, flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#1E293B' },
  roleSwitcherLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: '600' },
  roleSwitcherBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  roleSwitcherBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  roleSwitcherText: { fontSize: 11, fontWeight: '700', color: 'rgba(255,255,255,0.8)' },
  roleSwitcherTextActive: { color: '#fff' },
});
